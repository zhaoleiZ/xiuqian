package com.example.windsoul.qianqian.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Action;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.example.windsoul.qianqian.util.XCRoundImageView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class ContentsDetail extends AppCompatActivity {

    private ImageView Guanzhu;
    private ViewAdapter adapter;
    private Handler handler;
    private List<Map<String, Object>> data;
    Activity activity;
    int activityId;

    // 签到按钮
    private XCRoundImageView qiandao_button;
    TextView tvJoined;
    // 留言板
    private TextView chatting;


    // 发送服务器的数据信息
    private   int[] arr = new int[2];
    private ListView contentListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dxy_activity_contents_detail);

        // 签到按钮
        qiandao_button = findViewById(R.id.qiandao_button);



        // 留言
        chatting = findViewById(R.id.chatting);

        // 签到的人
        tvJoined = findViewById(R.id.activities_detail_joined_zl);


        // 关注按钮
        Guanzhu = findViewById(R.id.activities_detail_qian_zl);
        handler = new Handler();

        Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").create();
        Intent intent = getIntent();
        String activityGson = intent.getStringExtra("activity");
        activity = gson.fromJson(activityGson, Activity.class);
        activityId = activity.getActivityId();

        //判断是否登陆了，如果没登陆，那么 所有的活动都没关注。

        init();

        UserManager userManager = new UserManager();

        if (userManager.getCurrentUser() == null) {

            Guanzhu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent1 = new Intent(ContentsDetail.this, LoginActivity.class);
                    startActivity(intent1);
                    overridePendingTransition(R.anim.leftin, R.anim.rightout);
                }
            });

        } else { //已经登陆的用户

            int userId = userManager.getCurrentUser().getUserId();
            arr[0] = userId;
            arr[1] = activityId;
            final String arrGosn = gson.toJson(arr);

            // 登陆将用户的ID和这个活动的ID发送到服务器 判断当前用户是否关注了此活动
            //连接数据库
            OkHttpClient okHttpClient = new OkHttpClient();
            //创建请求体对象
            RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                    arrGosn);
            //创建请求对象
            final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                    .url(Const.BASE_URL + "/User/userAttendactivityis.do")
                    .build();
            Call call = okHttpClient.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String info = response.body().string();

//                    Log.e("String", "当前用户是否关注了这项活动" + info);

                    Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();

                    boolean star = gson.fromJson(info, boolean.class);

                    if (star == true) {
                        // 说明用户关注了这项活动
                        Runnable runnable = new Runnable() {
                            @Override
                            public void run() {
                                Guanzhu.setImageResource(R.drawable.shoucanged);
                            }
                        };
                        handler.post(runnable);

                    }

                }

            });

            /**
             * 当点击关注按钮时，发送用户和活动到服务器 ，是之关联起来。并将图片改成实心的关注。
             * 查询数据库，有这条数据就删除，没有这条数据就添加。然后在改变图片。
             */

            Guanzhu.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Guanzhu.setImageResource(R.drawable.shoucanged);
                    OkHttpClient okHttpClient = new OkHttpClient();
                    RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                            arrGosn);
                    final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                            .url(Const.BASE_URL + "Activity/updateAttendNum.do")
                            .build();
                    Call call1 = okHttpClient.newCall(request);
                    call1.enqueue(new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            e.printStackTrace();
                        }

                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            String info = response.body().string();
                            Gson gson = new Gson();
                            int star = gson.fromJson(info, int.class);
//                            Log.e("TGA", "用户关联这样活动是否成功--> " + info);
                            if (star == 1) {// 删除这条
                                Runnable runnable1 = new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(ContentsDetail.this, "取消关注", Toast.LENGTH_SHORT).show();
                                        Guanzhu.setImageResource(R.drawable.shoucang);
                                        // 并且签到按钮图片更改，并不可点击。
                                        qiandao_button.setImageResource(R.drawable.qiandao_1);
                                        qiandao_button.setVisibility(View.INVISIBLE);
                                    }
                                };
                                handler.post(runnable1);
                            } else if (star == 2) { // 插入这条
                                Runnable runnable2 = new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(ContentsDetail.this, "关注成功", Toast.LENGTH_SHORT).show();
                                        Guanzhu.setImageResource(R.drawable.shoucanged);
                                        qiandao_button.setVisibility(View.VISIBLE);
                                    }
                                };
                                handler.post(runnable2);
                            }
                        }

                    });
                }
            });


            /**
             * 判断当前用户是否今日签到
             */

            RequestBody requestBody2 = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                    arrGosn);
            //创建请求对象
            final Request request2 = new Request.Builder().post(requestBody2)//设置成post请求,参数是请求体
                    .url(Const.BASE_URL + "/User/isSigninToday.do")
                    .build();
            Call call2 = okHttpClient.newCall(request2);
            call2.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String info = response.body().string();

//                    Log.e("String", "当前用户今日是否签到" + info);

                    Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();

                    boolean star = gson.fromJson(info, boolean.class);

                    if (star == true) {
                        // 说明用户今日签到
                        Runnable runnable = new Runnable() {
                            @Override
                            public void run() {
                                qiandao_button.setImageResource(R.drawable.qiandao_2);
                            }
                        };
                        handler.post(runnable);

                    }

                }

            });


            /**
             * 当前用户签到逻辑，点击后连接服务器。并更换图片。
             */

            qiandao_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
//                    Guanzhu.setImageResource(R.drawable.shoucanged);
                    OkHttpClient okHttpClient = new OkHttpClient();
                    RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                            arrGosn);
                    final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                            .url(Const.BASE_URL + "Activity/updateSigninTime.do")
                            .build();
                    Call call1 = okHttpClient.newCall(request);
                    call1.enqueue(new Callback() {
                        @Override
                        public void onFailure(Call call, IOException e) {
                            e.printStackTrace();
                        }

                        @Override
                        public void onResponse(Call call, Response response) throws IOException {
                            String info = response.body().string();
                            Gson gson = new Gson();
                            boolean star = gson.fromJson(info, boolean.class);
//                            Log.e("TGA", "用户签到是否成功--> " + info);
                            if (star == true) { // 签到成功
                                Runnable runnable1 = new Runnable() {
                                    @Override
                                    public void run() {
                                        Toast.makeText(ContentsDetail.this, "签到成功", Toast.LENGTH_SHORT).show();
                                        qiandao_button.setImageResource(R.drawable.qiandao_2);
                                        init();
                                    }
                                };
                                handler.post(runnable1);
                            }
                            }


                    });

                }


            });



        }


    }

    public class ViewAdapter extends BaseAdapter {

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;


        public ViewAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }


        @Override
        //返回当前Adapter数据项个数
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {


            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);

            }

            TextView chatMsg = (TextView) convertView.findViewById(R.id.activities_detail_chatmsg_zl);
            TextView chatUsername = (TextView) convertView.findViewById(R.id.activities_detail_chatusername_zl);

            Map<String,Object> map = data.get(position);

            chatMsg.setText(map.get("chatMsg").toString());
            chatUsername.setText(map.get("chatUsername").toString());

            return convertView;

        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.leftin,R.anim.rightout);
    }

    private  void init(){
        //通过发送 activityId 到服务器 获取 参与者和留言记录
        Gson gson1 = new Gson();
        String acsId = gson1.toJson(activityId);

        OkHttpClient okHttpClient1 = new OkHttpClient();
        //创建请求体对象
        RequestBody requestBody1 = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                acsId);
        //创建请求对象
        final Request request1 = new Request.Builder().post(requestBody1)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "/User/selectAlluserNamebyactivityId.do")
                .build();
        Call call1 = okHttpClient1.newCall(request1);
        call1.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String info = response.body().string();
//                Log.e("String", "返回的参与者姓名" + info);

                Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();

                Type type1 = new TypeToken<List<String>>() {
                }.getType();
                final ArrayList<String> stares = gson.fromJson(info, type1);


                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        for (String str : stares) {
                            tvJoined.setText(str);
                        }

                    }
                };
                handler.post(runnable);

            }

        });


        //返回页面
        ImageView ivBack = findViewById(R.id.activities_detail_back_zl);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //活动名
        TextView activitiesName = findViewById(R.id.activities_detail_name_zl);
        activitiesName.setText(activity.getActivityTitle());

        //活动图片
        ImageView activityImage = findViewById(R.id.activities_detail_mainimg_zl);
        Glide.with(this).load(Const.BASE_URL+activity.getActivityImageUrl()).into(activityImage);

        //用户头像 -- >
        XCRoundImageView userImage = findViewById(R.id.activities_detail_user_img_zl);
        Glide.with(this).load(Const.BASE_URL+activity.getActivityStartUser().getUserImageUrl()).into(userImage);

        //用户名
        TextView tvUsername = findViewById(R.id.activities_detail_username_zl);
        tvUsername.setText(activity.getActivityStartUser().getUserName());
        //创建时间
        TextView tvTime = findViewById(R.id.activities_detail_time_zl);
        Date date = activity.getActivityStartTime();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        String dateStr = sdf.format(date);
        tvTime.setText(dateStr);
        //活动的内容
        TextView tvContent = findViewById(R.id.activities_detail_content_zl);
        tvContent.setText(activity.getActivityIntroduce());

        // 留言板 ，点击之后跳转留言区
        chatting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ContentsDetail.this,ChattingRoom.class);

                intent.putExtra("activityId",activityId);
                intent.putExtra("activity_title",activity.getActivityTitle());
                startActivity(intent);
                overridePendingTransition(R.anim.rightin,R.anim.leftout);
            }
        });


    }
}

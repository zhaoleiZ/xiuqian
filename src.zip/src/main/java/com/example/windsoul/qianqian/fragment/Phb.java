package com.example.windsoul.qianqian.fragment;


import com.bumptech.glide.Glide;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Intent;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;


import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.activity.ContentsDetail;
import com.example.windsoul.qianqian.activity.FollowingUserDetailActivity;
import com.example.windsoul.qianqian.activity.MainActivity;
import com.example.windsoul.qianqian.activity.UserDetailActivity;
import com.example.windsoul.qianqian.bean.Action;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.example.windsoul.qianqian.util.Util;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;

import okhttp3.Response;


/**
 * Created by 雪怡 on 2018/5/16.
 */

public class Phb extends Fragment {
    private ListView contentListView;
    private ListAdapter adapter;
    private HashMap<String, View> map;
    private List<Map<String, Object>> data;
    private boolean is=false;
    private TextView nice;
    private TextView hot;
    private TextView many;
    private Handler handler = null;
    private  View views;


    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        views = inflater.inflate(R.layout.fragment_phb,
                container,false);

        View v =  views.findViewById(R.id.phb_content);

        nice = views.findViewById(R.id.nice);
        hot = views.findViewById(R.id.hot);
        many = views.findViewById(R.id.many);
        handler = new Handler();

        /**
         * 默认listview为热门活动
         */

        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder().url(Const.BASE_URL+"Activity/hotActivity.do").build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String activityListStr = response.body().string();

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<Activity>>(){}.getType();
                List<Activity> activities=gson.fromJson(activityListStr,type1);


                data = new ArrayList<>();
                // 从数据库中 拿到数据啊

                ArrayList<Activity> acs = (ArrayList<Activity>) activities;

                for (int i=0;i<acs.size();i++) {
                    Map<String,Object> map = new HashMap<String, Object>();
                    map.put("image",acs.get(i).getActivityImageUrl());
                    map.put("title",acs.get(i).getActivityTitle());
                    map.put("number",acs.get(i).getActivityAttendNum());
                    map.put("activity",gson.toJson(acs.get(i)));
                    data.add(map);
                }


                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView = (ListView)views.findViewById(R.id.phb_lv);
                        adapter = new ViewAdapter_ACS(Phb.this.getContext(),R.layout.dxy_user_list_item,data);
                        contentListView.setAdapter(adapter);
                        contentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                Intent intent = new Intent(getActivity(),ContentsDetail.class);
                                TextView gsonStr = (TextView)view.findViewById(R.id.acs);
                                String son = gsonStr.getText().toString();
                                Log.e("son",son);
                                intent.putExtra("activity",son);
                                startActivity(intent);
                                getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                            }
                        });
                    }
                };
                handler.post(runnable);

            }
        });


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            v.setStateListAnimator(null);
        }

        final int a = R.drawable.down;
        final int b = R.drawable.up;
        final View view = views.findViewById(R.id.phb_content); //获取到要隐藏显示的linerlayout
        final ImageView imageView = views.findViewById(R.id.upanddown); //获取到按钮（imageview）
        final int hight =view.getHeight();
        //纵向拉伸
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(!is) {
                    //需要显示
                    view.setVisibility(View.VISIBLE);
                    imageView.setImageDrawable(getResources().getDrawable(b));
                    ValueAnimator animator = createValueAnimator(0,370,view);
                    animator.setDuration(500);
                    animator.start();
                    //设置下一层颜色为浅
                    is=true;

                }else{
                    //需要隐藏
                    imageView.setImageDrawable(getResources().getDrawable(a));
                    ValueAnimator animator = createValueAnimator(370,0,view);
                    animator.setDuration(500);
                    animator.addListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            super.onAnimationEnd(animation);
                            view.setVisibility(View.GONE);
                        }
                    });
                    animator.start();
                    is=false;
                }
            }
        });

        // 设置监听
        OnClickListenerImpl listener = new OnClickListenerImpl();
        many.setOnClickListener(listener);
        hot.setOnClickListener(listener);
        nice.setOnClickListener(listener);

        return views;
    }

    private ValueAnimator createValueAnimator(int start, int end, final View view){
        ValueAnimator animator = ValueAnimator.ofInt(start,end);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int value = (int)animation.getAnimatedValue();
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                layoutParams.height = value;
                view.setLayoutParams(layoutParams);
            }
        });
        return animator;
    }


    public class ViewAdapter_ACS extends BaseAdapter {

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;


        public ViewAdapter_ACS(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }


        @Override
        //返回当前Adapter数据项个数
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);
            }

            ImageView images = (ImageView) convertView.findViewById(R.id.image);
            TextView title = (TextView) convertView.findViewById(R.id.title);
            TextView number = convertView.findViewById(R.id.number);

            Map<String,Object> map = data.get(position);

            Glide.with(context).load(Const.BASE_URL+map.get("image")).into(images);
            title.setText(map.get("title").toString());
            number.setText(map.get("number").toString());

            TextView acs = convertView.findViewById(R.id.acs);
            acs.setText(map.get("activity").toString());


            return convertView;

        }
    }

    public class ViewAdapter_User extends BaseAdapter {

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;


        public ViewAdapter_User(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }


        @Override
        //返回当前Adapter数据项个数
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);
            }

            ImageView images = (ImageView) convertView.findViewById(R.id.image);
            TextView title = (TextView) convertView.findViewById(R.id.title);
            TextView number = convertView.findViewById(R.id.number);

            Map<String,Object> map = data.get(position);

            Glide.with(context).load(Const.BASE_URL+map.get("image")).into(images);
            title.setText(map.get("title").toString());
            number.setText(map.get("number").toString());


            TextView user = convertView.findViewById(R.id.user);
            user.setText(map.get("user").toString());


            return convertView;

        }
    }


    //排行榜（热门活动） hot

    private void showHotActivities() {
        //需要隐藏
        final int a = R.drawable.down;
        final int b = R.drawable.up;
        final View view = views.findViewById(R.id.phb_content);
        final ImageView imageView = views.findViewById(R.id.upanddown);
        imageView.setImageDrawable(getResources().getDrawable(a));
        ValueAnimator animator = createValueAnimator(370,0,view);
        animator.setDuration(500);
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                view.setVisibility(View.GONE);
            }
        });
        animator.start();
        is=false;

        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder().url(Const.BASE_URL+"Activity/hotActivity.do").build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String activityListStr = response.body().string();

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<Activity>>(){}.getType();
                List<Activity> activities=gson.fromJson(activityListStr,type1);


                data = new ArrayList<>();
                // 从数据库中 拿到数据啊

                ArrayList<Activity> acs = (ArrayList<Activity>) activities;

                for (int i=0;i<acs.size();i++) {
                    Map<String,Object> map = new HashMap<String, Object>();
                    map.put("image",acs.get(i).getActivityImageUrl());
                    map.put("title",acs.get(i).getActivityTitle());
                    map.put("number",acs.get(i).getActivityAttendNum());
                    map.put("activity",gson.toJson(acs.get(i)));
                    data.add(map);
                }


                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView = (ListView)views.findViewById(R.id.phb_lv);
                        adapter = new ViewAdapter_ACS(Phb.this.getContext(),R.layout.dxy_user_list_item,data);
                        contentListView.setAdapter(adapter);
                        contentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                Intent intent = new Intent(getActivity(),ContentsDetail.class);
                                TextView gsonStr = (TextView)view.findViewById(R.id.acs);
                                String son = gsonStr.getText().toString();
                                Log.e("son",son);
                                intent.putExtra("activity",son);
                                startActivity(intent);
                                getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                            }
                        });

                    }
                };
                handler.post(runnable);

            }
        });


    }

    // 排行榜（签到） many

    private void getSigninmostUser() {
        //需要隐藏
        final int a = R.drawable.down;
        final int b = R.drawable.up;
        final View view = views.findViewById(R.id.phb_content);
        final ImageView imageView = views.findViewById(R.id.upanddown);
        imageView.setImageDrawable(getResources().getDrawable(a));
        ValueAnimator animator = createValueAnimator(370,0,view);
        animator.setDuration(500);
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                view.setVisibility(View.GONE);
            }
        });
        animator.start();
        is=false;

        OkHttpClient okHttpClient = new OkHttpClient();

        Request request = new Request.Builder().url(Const.BASE_URL+"Activity/getSigninmostUser.do").build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String actionListStr = response.body().string();
                final Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<Action>>(){}.getType();
                List<Action> actions = gson.fromJson(actionListStr,type1);

                data = new ArrayList<>();
                // 从数据库中 拿到数据啊

                ArrayList<Action> acs = (ArrayList<Action>) actions;

                for (int i=0;i<acs.size();i++) {
                    Map<String,Object> map = new HashMap<String, Object>();
                    map.put("image",acs.get(i).getUserId().getUserImageUrl());
                    map.put("title",acs.get(i).getUserId().getUserName());
                    map.put("number",acs.get(i).getSignInTime());
                    map.put("user",gson.toJson(acs.get(i).getUserId()));

                    data.add(map);
                }


                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView = (ListView)views.findViewById(R.id.phb_lv);
                        adapter = new ViewAdapter_User(Phb.this.getContext(),R.layout.dxy_layout_phb_qdzd_item,data);
                        contentListView.setAdapter(adapter);
                        contentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                TextView gsonStr = (TextView)view.findViewById(R.id.user);
                                String son = gsonStr.getText().toString();
                                Log.e("son",son);
                                User userClicked = gson.fromJson(son,User.class);
                                User user = UserManager.getCurrentUser();
                                if (userClicked.equals(user)){
                                    Intent intent = new Intent(Phb.this.getContext(),UserDetailActivity.class);
                                    intent.putExtra("FINISH","finish");
                                    startActivity(intent);
                                    getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                                }else {
                                    Intent intent = new Intent(getActivity(),FollowingUserDetailActivity.class);
                                    intent.putExtra("userGson",son);
                                    startActivity(intent);
                                    getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                                }
                            }
                        });

                    }
                };
                handler.post(runnable);

            }
        });

    }


    //排行榜（点赞）nice

    private void getPraisemostUser() {
        //需要隐藏
        final int a = R.drawable.down;
        final int b = R.drawable.up;
        final View view = views.findViewById(R.id.phb_content);
        final ImageView imageView = views.findViewById(R.id.upanddown);
        imageView.setImageDrawable(getResources().getDrawable(a));
        ValueAnimator animator = createValueAnimator(370,0,view);
        animator.setDuration(500);
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                view.setVisibility(View.GONE);
            }
        });
        animator.start();
        is=false;

        OkHttpClient okHttpClient = new OkHttpClient();

        Request request = new Request.Builder().url(Const.BASE_URL+"Activity/getPraisemostUser.do").build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {

                String userListStr = response.body().string();
                final Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<User>>(){}.getType();

                // userList
                ArrayList<User> users = gson.fromJson(userListStr,type1);


                data = new ArrayList<>();
                // 从数据库中 拿到数据啊

                ArrayList<User> acs =  users;
                for (int i=0;i<acs.size();i++) {
                    Map<String,Object> map = new HashMap<String, Object>();
                    map.put("image",acs.get(i).getUserImageUrl());
                    map.put("title",acs.get(i).getUserName());
                    map.put("number",acs.get(i).getUserIntroduce());
                    map.put("user",gson.toJson(acs.get(i)));
                    data.add(map);
                }


                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView = (ListView)views.findViewById(R.id.phb_lv);
                        adapter = new ViewAdapter_User(Phb.this.getContext(),R.layout.nice_user_item,data);
                        contentListView.setAdapter(adapter);
                        contentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                TextView gsonStr = (TextView)view.findViewById(R.id.user);
                                String son = gsonStr.getText().toString();
                                Log.e("niceSon",son);
                                User user = UserManager.getCurrentUser();
                                User userClicked = gson.fromJson(son,User.class);
                                if (userClicked.equals(user)){
                                    Intent intent = new Intent(Phb.this.getContext(),UserDetailActivity.class);
                                    intent.putExtra("FINISH","finish");
                                    startActivity(intent);
                                    getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                                }else{
                                    Intent intent = new Intent(getActivity(),FollowingUserDetailActivity.class);
                                    intent.putExtra("userGson",son);
                                    startActivity(intent);
                                    getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                                }
                            }
                        });

                    }
                };
                handler.post(runnable);

            }
        });

    }

    // 给排行榜按钮设置点击事件
    private class OnClickListenerImpl implements View.OnClickListener{
        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.hot:  //排行榜（热门活动）
                    showHotActivities();
                    break;
                case R.id.nice: // 排行榜（点赞）
                    getPraisemostUser();
                    break;
                case R.id.many://排行榜(签到)
                   getSigninmostUser();
                    break;
            }
        }
    }



}

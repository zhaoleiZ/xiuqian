package com.example.windsoul.qianqian.fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.activity.ContentsDetail;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.util.Const;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by 雪怡 on 2018/5/15.
 */



public class Search extends Fragment {
    private ListView contentListView;
    private ListAdapter adapter;
    private List<Map<String, Object>> data;

    private Handler handler;

    private OkHttpClient okHttpClient;

    private List<Activity> searchActivity;
    private TextView tvSearch;
    private TextView tvId;

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        searchActivity = new ArrayList<>();

        View view = inflater.inflate(R.layout.dxy_fragment_search,
                container, false);

        final EditText editText = view.findViewById(R.id.search_et);
        editText.setFocusableInTouchMode(true);
        editText.setFocusable(true);
        editText.requestFocus();

        tvSearch = view.findViewById(R.id.tv_search_zl);

        contentListView = view.findViewById(R.id.lv_search_zl);

        contentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                tvId = view.findViewById(R.id.tv_search_activities_id_zl);
                String activity = tvId.getText().toString();
//                Log.e("tag",activity);
                Intent intent = new Intent(Search.this.getContext(), ContentsDetail.class);
                intent.putExtra("activity",activity);
                startActivity(intent);

            }
        });

        okHttpClient = new OkHttpClient();
        handler = new Handler();
        showHotActivities();

        editText.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() != KeyEvent.ACTION_UP) {
                    String search = editText.getText().toString();
                    searchActivities(search);
                    Handler handler1 = new Handler();
                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            ViewGroup.LayoutParams params= tvSearch.getLayoutParams();
                            params.height = 0;
                            tvSearch.setLayoutParams(params);
                            tvSearch.setVisibility(View.INVISIBLE);
                        }
                    };
                    handler1.post(runnable);
                    if (search.isEmpty()){
                        showHotActivities();
                        Runnable runnable1 = new Runnable() {
                            @Override
                            public void run() {
                                //TODO
                                ViewGroup.LayoutParams params= tvSearch.getLayoutParams();
                                params.height = 80;
                                tvSearch.setLayoutParams(params);
                                tvSearch.setVisibility(View.VISIBLE);
                            }
                        };
                        handler1.post(runnable1);
                    }
                    return true;
                }
                return false;
            }
        });
        return view;
    }

    //获取搜索到的活动
    private void searchActivities(String searchStr) {
        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                searchStr);
        //创建请求对象
        final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "Activity/findActivityByStr.do")
                .build();

        //创建call对象，并执行请求
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String returnList = response.body().string();
                Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1 = new TypeToken<List<Activity>>() {
                }.getType();
                List<Activity> activities = gson.fromJson(returnList, type1);
                data = new ArrayList<>();
                for (int i = 0; i < activities.size(); i++) {
                    Map<String, Object> map = new HashMap<String, Object>();
                    map.put("image", activities.get(i).getActivityImageUrl());
                    map.put("title", activities.get(i).getActivityTitle());
                    map.put("number", activities.get(i).getActivityAttendNum());
                    map.put("activity",gson.toJson(activities.get(i)));
                    data.add(map);

                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            adapter = new ViewAdapter(Search.this.getContext(), R.layout.zl_layout_search_item, data);
                            contentListView.setAdapter(adapter);
                        }
                    };
                    handler.post(runnable);
                }
            }
        });
    }

    //获取热门搜索
    private void showHotActivities() {
        Request request = new Request.Builder().url(Const.BASE_URL+"Activity/hotActivity.do").build();
                Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String activityListStr = response.body().string();
                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<Activity>>(){}.getType();
                List<Activity> activities=gson.fromJson(activityListStr,type1);


                data = new ArrayList<>();
                // 从数据库中 拿到数据啊

                ArrayList<Activity> acs = (ArrayList<Activity>) activities;

                //热门搜索只显示5条信息
                if (acs.size()<=5) {
                    for (int i = 0; i < acs.size(); i++) {
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("image", acs.get(i).getActivityImageUrl());
                        map.put("title", acs.get(i).getActivityTitle());
                        map.put("number", acs.get(i).getActivityAttendNum());
                        map.put("activity", gson.toJson(acs.get(i)));
                        data.add(map);
                    }
                }else{
                    for (int i = 0; i < 5; i++) {
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("image", acs.get(i).getActivityImageUrl());
                        map.put("title", acs.get(i).getActivityTitle());
                        map.put("number", acs.get(i).getActivityAttendNum());
                        map.put("activity", gson.toJson(acs.get(i)));
                        data.add(map);
                    }
                }


                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        adapter = new ViewAdapter(Search.this.getContext(),R.layout.zl_layout_search_item,data);
                        contentListView.setAdapter(adapter);
                    }
                };
                handler.post(runnable);

            }
        });


    }

    public class ViewAdapter extends BaseAdapter {

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;

        public ViewAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);

            }

            TextView title = (TextView) convertView.findViewById(R.id.tv_search_result_zl);
            TextView tvId = (TextView)convertView.findViewById(R.id.tv_search_activities_id_zl);

            Map<String,Object> map = data.get(position);

            title.setText(map.get("title").toString());
            tvId.setText(map.get("activity").toString());
            return convertView;
        }
    }
}

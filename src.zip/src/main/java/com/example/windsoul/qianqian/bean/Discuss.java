package com.example.windsoul.qianqian.bean;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.sql.Date;
import java.util.Objects;

public class Discuss {
    private int discussId;
    private String discussIntroduce;
    private String discussImageUrl;
    private int discussPraise;
    private Date discussTime;

    private Action actionId;

    public Action getActionId() {
        return actionId;
    }

    public void setActionId(Action actionId) {
        this.actionId = actionId;
    }


    public int getDiscussId() {
        return discussId;
    }

    public void setDiscussId(int discussId) {
        this.discussId = discussId;
    }


    public String getDiscussIntroduce() {
        return discussIntroduce;
    }

    public void setDiscussIntroduce(String discussIntroduce) {
        this.discussIntroduce = discussIntroduce;
    }


    public String getDiscussImageUrl() {
        return discussImageUrl;
    }

    public void setDiscussImageUrl(String discussImageUrl) {
        this.discussImageUrl = discussImageUrl;
    }


    public int getDiscussPraise() {
        return discussPraise;
    }

    public void setDiscussPraise(int discussPraise) {
        this.discussPraise = discussPraise;
    }


    public Date getDiscussTime() {
        return discussTime;
    }

    public void setDiscussTime(Date discussTime) {
        this.discussTime = discussTime;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Discuss discuss = (Discuss) o;
        return discussId == discuss.discussId &&
                discussPraise == discuss.discussPraise &&
                Objects.equals(discussIntroduce, discuss.discussIntroduce) &&
                Objects.equals(discussImageUrl, discuss.discussImageUrl) &&
                Objects.equals(discussTime, discuss.discussTime);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {

        return Objects.hash(discussId, discussIntroduce, discussImageUrl, discussPraise, discussTime);
    }
}

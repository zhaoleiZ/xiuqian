package com.example.windsoul.qianqian.activity;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static android.content.ContentValues.TAG;

/**
 * Created by windsoul on 2018/5/8.
 */

public class RegisterActivity extends Activity implements View.OnClickListener {

    private TextView stuNum;
    TextView userName;
    TextView userPassword;
    TextView phone;

    private OkHttpClient okHttpClient;

    private int REQUEST_PERMISSION = 1;
    private int REQUEST_CODE = 2;

    private TextView mBtnRegister;

    private View progress;

    private View mInputLayout;

    private float mWidth, mHeight;

    private Handler handler;


    private LinearLayout input_layout_stu,input_layout_name,input_layout_psw,input_layout_repsw,input_layout_email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dxy_activity_register);

        //创建OKHttpClient
        okHttpClient = new OkHttpClient();//默认方法

        // 学号，用户名，密码，邮箱。
        stuNum = findViewById(R.id.register_et_stuno);
        userName = findViewById(R.id.register_et_username);
        userPassword = findViewById(R.id.register_et_password);
        phone = findViewById(R.id.register_et_email);

        handler = new Handler();

        initView();
    }

    private void initView() {
        mBtnRegister = (TextView) findViewById(R.id.btn_register);
        progress = findViewById(R.id.layout_progress);
        mInputLayout = findViewById(R.id.input_layout_register);
        input_layout_stu = (LinearLayout) findViewById(R.id.input_layout_stu);
        input_layout_name = (LinearLayout) findViewById(R.id.input_layout_name);
        input_layout_psw = findViewById(R.id.input_layout_psw);
        input_layout_repsw = findViewById(R.id.input_layout_repsw);
        input_layout_email = findViewById(R.id.input_layout_email);

        mBtnRegister.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        mWidth = mBtnRegister.getMeasuredWidth();
        mHeight = mBtnRegister.getMeasuredHeight();

        input_layout_stu.setVisibility(View.INVISIBLE);
        input_layout_name.setVisibility(View.INVISIBLE);
        input_layout_psw.setVisibility(View.INVISIBLE);
        input_layout_repsw.setVisibility(View.INVISIBLE);
        input_layout_email.setVisibility(View.INVISIBLE);

        inputAnimator(mInputLayout, mWidth, mHeight);

        httpRegister(stuNum.getText().toString(),userName
                .getText().toString(),userPassword.getText()
                .toString(),phone.getText().toString());

//        // 跳转到 活动页面
//        final Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
//
//        Handler handler = new Handler();
//        handler.postDelayed(new Runnable() {
//            @Override
//            public void run() {
//                startActivity(intent);
//            }
//        },3000);



    }

    private void inputAnimator(final View view, float w, float h) {

        AnimatorSet set = new AnimatorSet();

        ValueAnimator animator = ValueAnimator.ofFloat(0, w);
        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {

            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float value = (Float) animation.getAnimatedValue();
                ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) view
                        .getLayoutParams();
                params.leftMargin = (int) value;
                params.rightMargin = (int) value;
                view.setLayoutParams(params);
            }
        });

        ObjectAnimator animator2 = ObjectAnimator.ofFloat(mInputLayout,
                "scaleX", 1f, 0.5f);
        set.setDuration(1000);
        set.setInterpolator(new AccelerateDecelerateInterpolator());
        set.playTogether(animator, animator2);
        set.start();
        set.addListener(new Animator.AnimatorListener() {

            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAnimationEnd(Animator animation) {

                progress.setVisibility(View.VISIBLE);
                progressAnimator(progress);
                mInputLayout.setVisibility(View.INVISIBLE);

            }

            @Override
            public void onAnimationCancel(Animator animation) {
                // TODO Auto-generated method stub

            }
        });

    }

    private void progressAnimator(final View view) {
        PropertyValuesHolder animator = PropertyValuesHolder.ofFloat("scaleX",
                0.5f, 1f);
        PropertyValuesHolder animator2 = PropertyValuesHolder.ofFloat("scaleY",
                0.5f, 1f);
        ObjectAnimator animator3 = ObjectAnimator.ofPropertyValuesHolder(view,
                animator, animator2);
        animator3.setDuration(1000);
        animator3.setInterpolator(new JellyInterpolator());
        animator3.start();
    }

    /**
     *
     * @param userNum
     * @param userPassword
     */

    /**
     * 连接服务器
     */

    private void httpRegister(final String userNum, String userName, String userPassword, String phone) {

        Gson gson = new Gson();
        User user = new User();
        user.setUserNum(userNum);
        user.setUserName(userName);
        user.setUserPassword(userPassword);
        user.setUserPhone(phone);
        final String userGson = gson.toJson(user);
        Log.e("userGson",userGson);

        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                userGson);
        //创建请求对象
        Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL+"/User/userregister.do")
                .build();

//        Log.e("request",request.toString());

        //创建call对象，并执行请求
        final Call call = okHttpClient.newCall(request);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Response response = call.execute();
                    if(response.isSuccessful()){//判断响应是否成功
                        String returnRegiest = response.body().string();
                        Log.e(TAG,"同步："+returnRegiest);//获取服务器返回的字符串信息
                        if (returnRegiest.equals("true")){

                            //通过学号查询数据库获取用户信息
                            //创建请求体对象
                            RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                                    userNum);
                            //创建请求对象
                            final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                                    .url(Const.BASE_URL + "/User/selectUserbyuserNum.do")
                                    .build();

                            //创建call对象，并执行请求
                            Call call = okHttpClient.newCall(request);
                            call.enqueue(new Callback() {
                                @Override
                                public void onFailure(Call call, IOException e) {
                                    e.printStackTrace();
                                }

                                @Override
                                public void onResponse(Call call, Response response) throws IOException {
                                    String userGson = response.body().string();
                                    Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                                    User user = gson.fromJson(userGson,User.class);

                                    UserManager userManager = new UserManager();
                                    userManager.setCurrentUser(user);
                                }
                            });

                            Intent intent = new Intent(RegisterActivity.this,MainActivity.class);
                            startActivity(intent);
                            overridePendingTransition(R.anim.leftin,R.anim.rightout);
                        }else{
                            Runnable runnable = new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(getApplicationContext(),"注册失败",Toast.LENGTH_LONG).show();
                                    
                                }
                            };
                            handler.post(runnable);
                        }

                    }else{
                        Log.e(TAG,response.code()+"连接失败");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("TGA",e.toString());
                }
            }
        }).start();

    }
}

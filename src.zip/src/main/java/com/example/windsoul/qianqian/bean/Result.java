package com.example.windsoul.qianqian.bean;

/**
 * Created by windsoul on 2018/5/23.
 */

public class Result {
    int code;
    private  User user;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}


package com.example.windsoul.qianqian.activity;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.Window;

import com.example.windsoul.qianqian.R;

/**
 * Created by 雪怡 on 2018/5/9.
 */

public class ResetPasswordActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.layout_resetpassword);
    }
}

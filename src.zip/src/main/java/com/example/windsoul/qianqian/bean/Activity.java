package com.example.windsoul.qianqian.bean;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.sql.Date;
import java.sql.Time;
import java.util.Objects;


public class Activity {
    private Integer activityId;
    private String activityTitle;
    private String activityIntroduce;
    private String activityImageUrl;
    private Date activityStartTime;
    private Date activityEndTime;
    private Integer activityModel;
    private Integer activityUserNumber;
    private Integer activityAttendNum;
    private Integer activityIsPrivate;

    private User activityStartUser;
    private Punish punishId;

    public Integer getActivityIsPrivate() {
        return activityIsPrivate;
    }

    public void setActivityIsPrivate(Integer activityIsPrivate) {
        this.activityIsPrivate = activityIsPrivate;
    }

    public Integer getActivityId() {
        return activityId;
    }

    public void setActivityId(Integer activityId) {
        this.activityId = activityId;
    }

    public String getActivityTitle() {
        return activityTitle;
    }

    public void setActivityTitle(String activityTitle) {
        this.activityTitle = activityTitle;
    }

    public String getActivityIntroduce() {
        return activityIntroduce;
    }

    public void setActivityIntroduce(String activityIntroduce) {
        this.activityIntroduce = activityIntroduce;
    }

    public String getActivityImageUrl() {
        return activityImageUrl;
    }

    public void setActivityImageUrl(String activityImageUrl) {
        this.activityImageUrl = activityImageUrl;
    }

    public Date getActivityStartTime() {
        return activityStartTime;
    }

    public void setActivityStartTime(Date activityStartTime) {
        this.activityStartTime = activityStartTime;
    }

    public Date getActivityEndTime() {
        return activityEndTime;
    }

    public void setActivityEndTime(Date activityEndTime) {
        this.activityEndTime = activityEndTime;
    }

    public Integer getActivityModel() {
        return activityModel;
    }

    public void setActivityModel(Integer activityModel) {
        this.activityModel = activityModel;
    }

    public Integer getActivityUserNumber() {
        return activityUserNumber;
    }

    public void setActivityUserNumber(Integer activityUserNumber) {
        this.activityUserNumber = activityUserNumber;
    }

    public Integer getActivityAttendNum() {
        return activityAttendNum;
    }

    public void setActivityAttendNum(Integer activityAttendNum) {
        this.activityAttendNum = activityAttendNum;
    }

    public User getActivityStartUser() {
        return activityStartUser;
    }

    public void setActivityStartUser(User activityStartUser) {
        this.activityStartUser = activityStartUser;
    }

    public Punish getPunishId() {
        return punishId;
    }

    public void setPunishId(Punish punishId) {
        this.punishId = punishId;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Activity activity = (Activity) o;
        return Objects.equals(activityId, activity.activityId) &&
                Objects.equals(activityTitle, activity.activityTitle) &&
                Objects.equals(activityIntroduce, activity.activityIntroduce) &&
                Objects.equals(activityImageUrl, activity.activityImageUrl) &&
                Objects.equals(activityStartTime, activity.activityStartTime) &&
                Objects.equals(activityEndTime, activity.activityEndTime) &&
                Objects.equals(activityModel, activity.activityModel) &&
                Objects.equals(activityUserNumber, activity.activityUserNumber) &&
                Objects.equals(activityAttendNum, activity.activityAttendNum)&&
                Objects.equals(activityIsPrivate, activity.activityIsPrivate);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {

        return Objects.hash(activityId, activityTitle, activityIntroduce, activityImageUrl, activityStartTime, activityEndTime, activityModel, activityUserNumber, activityAttendNum,activityIsPrivate);
    }
}

package com.example.windsoul.qianqian.util;

/**
 * Created by windsoul on 2018/6/6.
 */

public class Const {
    public static String BASE_URL = "http://10.0.2.2:8080/";
}

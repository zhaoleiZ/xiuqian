package com.example.windsoul.qianqian.activity;

import android.Manifest;
import android.animation.TimeAnimator;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Action;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.SwitchButton;
import com.example.windsoul.qianqian.util.UserManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;
import java.io.IOException;
import java.sql.Date;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;



public class CreateActivity extends AppCompatActivity {

    private int REQUEST_PERMISSION = 1;
    private int REQUEST_CODE = 2;
    private OkHttpClient okHttpClient;
    private Handler handler;

    private LinearLayout layoutCreateTime;
    private LinearLayout layoutWays;
    private LinearLayout layout_create_people_dxy;
    private ImageView addimg;
    private User user;
    private Activity activity;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.zl_activity_create);

        activity = new Activity();
        user = UserManager.getCurrentUser();

        activity.setActivityStartUser(user);//活动的创建者

        okHttpClient = new OkHttpClient();
        handler = new Handler();

        //返回页面
        ImageView ivBack = findViewById(R.id.create_back_zl);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // 发表按钮
        TextView tvCreate = findViewById(R.id.create_create_zl);
        //限制时间
        layoutCreateTime = (LinearLayout) findViewById(R.id.layout_create_time_zl);
        //惩罚措施
        layoutWays = (LinearLayout)findViewById(R.id.layout_create_ways_zl);
        // 限制人数
        layout_create_people_dxy = findViewById(R.id.layout_create_people_dxy);

        //活动标题
        final EditText etCreateHeading = (EditText) findViewById(R.id.et_create_headline_zl);
        etCreateHeading.setFocusableInTouchMode(true);
        etCreateHeading.setFocusable(true);
        etCreateHeading.requestFocus();
        activity.setActivityTitle(etCreateHeading.getText().toString());
        final TextView tvCreateHeading = findViewById(R.id.tv_create_headline_zl);
        //活动内容
        final EditText etContent = (EditText)findViewById(R.id.et_create_content_zl);
        etContent.setFocusableInTouchMode(true);
        etContent.setFocusable(true);
        String content = etContent.getText().toString();

        activity.setActivityIsPrivate(1);
        //设置是否私有
        SwitchButton btnCreatePrivate = findViewById(R.id.switchbtn_create_private_zl);
        btnCreatePrivate.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
                //TODO do your job
                if(!isChecked) {
                    Log.e("tag","------> isChecked"+isChecked);
                    activity.setActivityIsPrivate(0);
                    Log.e("tag","--------> getActivityIsPrivate "+ activity.getActivityIsPrivate());
                }else{
                    Log.e("tag","------> isChecked"+isChecked);
                    activity.setActivityIsPrivate(1);
                    Log.e("tag","--------> getActivityIsPrivate "+ activity.getActivityIsPrivate());
                }
            }
        });

        //设置活动模式
        activity.setActivityModel(1);
        SwitchButton btnActivityState = findViewById(R.id.switchbtn_create_state_zl);
        btnActivityState.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
                if (!isChecked){
                    TextView underthetime = findViewById(R.id.dxy_underthetime);
                    underthetime.setVisibility(View.INVISIBLE);
                    layoutCreateTime.setVisibility(View.INVISIBLE);
                    layoutWays.setVisibility(View.INVISIBLE);
                    layout_create_people_dxy.setVisibility(View.INVISIBLE);
                    activity.setActivityModel(0);
                }else{
                    TextView underthetime = findViewById(R.id.dxy_underthetime);
                    underthetime.setVisibility(View.VISIBLE);
                    layoutCreateTime.setVisibility(View.VISIBLE);
                    layoutWays.setVisibility(View.VISIBLE);
                    layout_create_people_dxy.setVisibility(View.VISIBLE);
                    activity.setActivityModel(1);
                }
            }
        });


        //设置时间滚轴
        Calendar calendar = Calendar.getInstance();

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DATE);


        // 最晚签到时间设置成当前时间


        //设置活动的开始日期和结束日期
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date(System.currentTimeMillis());//获取当前时间
        String strData = sdf.format(date);

        final TextView showBeginTime = findViewById(R.id.tv_show_begintime_zl);
        final TextView showEndTime = findViewById(R.id.tv_show_endtime_zl);

        if (showBeginTime.getText().toString().isEmpty()){
            showBeginTime.setText(strData);
        }
        if (showEndTime.getText().toString().isEmpty()){
            showEndTime.setText(strData);
        }
        //开始日期对话框
        final DatePickerDialog dpfBegin = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                int realMonth = month+1;
                showBeginTime.setText(year+"-"+realMonth+"-"+dayOfMonth);
            }
        },year,month,day);

        //设置开始时间的点击事件
        ImageView btnBegin = findViewById(R.id.imagebtn_begintime_zl);
        btnBegin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dpfBegin.show();
            }
        });

        //结束日期对话框
        final DatePickerDialog dpfEnd = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                int realMonth = month+1;
                showEndTime.setText(year+"-"+realMonth+"-"+dayOfMonth);
            }
        },year,month,day);
        //设置结束时间点击事件
        ImageView btnEnd = findViewById(R.id.imagebtn_endtime_zl);
        btnEnd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dpfEnd.show();
            }
        });

        //设置人数
        final EditText numet = findViewById(R.id.dxy_edittextnum);
        numet.setFocusableInTouchMode(true);
        numet.setFocusable(true);

        //上传图片
        addimg = findViewById(R.id.create_addimg_zl);

        addimg.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                //打开手机相册，动态申请权限
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_PERMISSION);
            }
        });

        //点击发布按钮
        tvCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String headingStr = String.valueOf(etCreateHeading.getText());

                    if (!headingStr.isEmpty()) {
                        //活动标题
                        activity.setActivityTitle(headingStr);
                    }

                //活动内容
                activity.setActivityIntroduce(etContent.getText().toString());
                //活动开始时间
                String beginDateStr = showBeginTime.getText().toString();
                SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
                try {
                    java.util.Date beginDate = sf.parse(beginDateStr);
                    Date sqlBegin = new Date(beginDate.getTime());
                    activity.setActivityStartTime(sqlBegin);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                //活动结束时间
                String endDateStr = showEndTime.getText().toString();
                SimpleDateFormat sf1 = new SimpleDateFormat("yyyy-MM-dd");

                try {
                    java.util.Date endDate = sf1.parse(endDateStr);
                    Date sqlEnd = new Date(endDate.getTime());
                    activity.setActivityEndTime(sqlEnd);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                //活动的限制人数
                String limiteStr = numet.getText().toString();
                if (limiteStr.isEmpty()){
                    activity.setActivityUserNumber(20);
                }else {
                    int num = Integer.parseInt(limiteStr);
                    activity.setActivityUserNumber(num);
                }
                activity.setActivityStartUser(user);


                //上传活动
                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                String activityGson = gson.toJson(activity);
                Log.e("activityGson",activityGson);

                //创建请求体对象
                RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                        activityGson);
                //创建请求对象
                final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                        .url(Const.BASE_URL + "Activity/userinsertActivitys.do")
                        .build();
                //创建call对象，并执行请求
                Call call = okHttpClient.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        Boolean isSuccess = Boolean.valueOf(response.body().string());

                        if(isSuccess){
                            Runnable runnable = new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(CreateActivity.this,"创建成功",Toast.LENGTH_LONG).show();
                                }
                            };
                            handler.post(runnable);
                            Action action = new Action();
                            action.setUserId(user);

                        }else{
                            Runnable runnable = new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(CreateActivity.this,"创建失败",Toast.LENGTH_LONG).show();
                                }
                            };
                            handler.post(runnable);
                        }
                    }
                });

            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == REQUEST_CODE){
            //获取照片
            Uri uri = data.getData();//获取图片的Uri
            //后四个参数是查询的字段，条件等
            Cursor cursor = this.getContentResolver().query(uri,null,null,null,null);
            cursor.moveToFirst();
            //MediaStore媒体库 MediaStore.Images.Media.DATA;本质就是一个字符串
            String column = MediaStore.Images.Media.DATA;
            int columnIndex = cursor.getColumnIndex(column);
            String path = cursor.getString(columnIndex);//获取路径（在SD卡中的地址）
            File file = new File(path);
            doUploadFile(file);
        }
    }

    //申请动态权限的回调方法
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //打开手机相册
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,REQUEST_CODE);
    }

    private void doUploadFile(File file){
        //构造请求体
        RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"),file);
        //创建请求
        final Request request = new Request.Builder().url(Const.BASE_URL+"/UploadFile").post(requestBody).build();
        //执行
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                final String path = response.body().string();
                activity.setActivityImageUrl(path);//活动的图片
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
//                        Log.e("路径：",Const.BASE_URL+path);
                        Glide.with(CreateActivity.this).load(Const.BASE_URL+path).into(addimg);
                    }
                };
                handler.post(runnable);
            }
        });
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.leftin,R.anim.rightout);
    }
}

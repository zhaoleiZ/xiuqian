package com.example.windsoul.qianqian.util;
import android.content.Context;

import com.example.windsoul.qianqian.activity.LoginActivity;
import com.example.windsoul.qianqian.bean.User;

/**
 * @author: Lemon-XQ
 * @date: 2018/2/10
 */

public class UserManager {

    public static User mUser;

    public static User getCurrentUser(){
        return mUser;
    }

    public static void setCurrentUser(User user){

        mUser = user;
    }

    public static void clear(){
        mUser = null;
    }
}

package com.example.windsoul.qianqian.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MyCreateActivity extends AppCompatActivity {
    private ViewAdapter adapter;

    private List<Map<String, Object>> data;

    private ListView contentListView;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.zl_activity_my_create);

        handler = new Handler();

        ImageView ivBack = findViewById(R.id.mycreate_back_zl);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //页面跳转
        ImageView ivCreate = findViewById(R.id.iv_mycreate_add_zl);
        ivCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MyCreateActivity.this,CreateActivity.class);
                startActivity(intent);
            }
        });

        final Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
        //获取当前登录的用户
        User user = UserManager.getCurrentUser();
        int intId = user.getUserId();
        String userId = gson.toJson(intId);
        //用户发表的活动
        //TODO 查询数据库 获取用户创建的活动
        OkHttpClient okHttpClient = new OkHttpClient();
        final RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                userId);
        Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "/Activity/selectActivitiesByUserId.do")
                .build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String activitiesList = response.body().string();
                Log.e("TAG",activitiesList);

                Gson gson1=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<Activity>>(){}.getType();
                List<Activity> activities=gson1.fromJson(activitiesList,type1);

                data = new ArrayList<>();
                for(int i=0;i<activities.size();i++){
                    Map<String,Object> map = new HashMap<String,Object>();
                    map.put("images",activities.get(i).getActivityImageUrl());//图片
                    map.put("title",activities.get(i).getActivityTitle());//活动名
                    map.put("info",activities.get(i).getActivityIntroduce());//活动简介
                    String activityGson = gson.toJson(activities.get(i));
                    map.put("activity",activityGson);

                    data.add(map);
                }

                contentListView = (ListView)findViewById(R.id.ls_mycreate_zl);
                adapter = new ViewAdapter(MyCreateActivity.this,R.layout.zl_mycreate_list_item,data);

                contentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        Intent intent = new Intent(MyCreateActivity.this,ContentsDetail.class);
                        TextView gsonStr = (TextView)view.findViewById(R.id.tv_mycreate_acs);
                        String son = gsonStr.getText().toString();

                        intent.putExtra("activity",son);
                        startActivity(intent);
                        MyCreateActivity.this.overridePendingTransition(R.anim.rightin,R.anim.leftout);
                    }
                });

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView.setAdapter(adapter);
                    }
                };
                handler.post(runnable);

            }
        });


    }

    public class ViewAdapter extends BaseAdapter{

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;

        public ViewAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);

            }

            ImageView images = (ImageView) convertView.findViewById(R.id.iv_mycreate_normal_zl);
            TextView caption = (TextView) convertView.findViewById(R.id.tv_mycreate_caption_zl);
            TextView info = (TextView)convertView.findViewById(R.id.tv_mycreate_info);
            TextView activityGson = (TextView)convertView.findViewById(R.id.tv_mycreate_acs);

            Map<String,Object> map = data.get(position);

            Glide.with(MyCreateActivity.this).load(Const.BASE_URL+map.get("images").toString()).into(images);
            caption.setText(map.get("title").toString());
            info.setText(map.get("info").toString());
            activityGson.setText(map.get("activity").toString());

            return convertView;
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.leftin,R.anim.rightout);
    }

    @Override
    public void startActivity(Intent intent) {
        super.startActivity(intent);
        overridePendingTransition(R.anim.rightin,R.anim.leftout);
    }
}

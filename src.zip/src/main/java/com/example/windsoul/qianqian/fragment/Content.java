package com.example.windsoul.qianqian.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.etsy.android.grid.StaggeredGridView;
import com.example.windsoul.qianqian.activity.ContentsDetail;
import com.example.windsoul.qianqian.activity.CreateActivity;
import com.example.windsoul.qianqian.activity.MainActivity;
import com.example.windsoul.qianqian.activity.MyCreateActivity;
import com.example.windsoul.qianqian.activity.LoginActivity;
//import com.example.windsoul.qianqian.activity.MyCreateActivity;
import com.example.windsoul.qianqian.activity.SignActivity;
import com.example.windsoul.qianqian.activity.Star;
import com.example.windsoul.qianqian.activity.UserDetailActivity;
import com.example.windsoul.qianqian.adapter.CardsAnimationAdapter;
import com.example.windsoul.qianqian.adapter.PageAdapter;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.function.SlideMenu;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.SharedPreferencesUtil;
import com.example.windsoul.qianqian.util.UserManager;
import com.example.windsoul.qianqian.util.XCRoundImageView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.nhaarman.listviewanimations.swinginadapters.AnimationAdapter;
import com.yalantis.phoenix.PullToRefreshView;

import com.example.windsoul.qianqian.R;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by windsoul on 2018/5/8.
 */


public class Content extends Fragment  {


    private StaggeredGridView mPage;
    // 初始化数据
    private List<Map<String, Object>> data;
    private BaseAdapter mAdapter;

    private Handler handler = null;
    private PullToRefreshView mPullToRefreshView ;

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        final View view = inflater.inflate(R.layout.fragment_content_list,
                container,false);

        handler = new Handler();

        // 从数据库中 拿到数据啊

        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder().url(Const.BASE_URL+"/Activity/appshowActivitys.do").build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String activityListStr = response.body().string();
                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<Activity>>(){}.getType();
                List<Activity> activities=gson.fromJson(activityListStr,type1);
                data = new ArrayList<>();
                // 从数据库中 拿到数据啊
                ArrayList<Activity> acs = (ArrayList<Activity>) activities;
                for (int i=0;i<acs.size();i++) {
                    Map<String,Object> map = new HashMap<String, Object>();
                    map.put("image",acs.get(i).getActivityImageUrl());
                    map.put("title",acs.get(i).getActivityTitle());
                    map.put("info",acs.get(i).getActivityIntroduce());
                    map.put("activity",gson.toJson(acs.get(i)));
                    data.add(map);
                }


                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        mPage = (StaggeredGridView) view.findViewById(R.id.page);
                        mAdapter=new PageAdapter(Content.this.getContext(), R.layout.content_list_item,data);
                        AnimationAdapter animationAdapter = new CardsAnimationAdapter(mAdapter);
                        animationAdapter.setAbsListView(mPage);
                        mPage.setAdapter(animationAdapter);

                        mPage.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                Intent intent = new Intent(getActivity(),ContentsDetail.class);
                                TextView gsonStr = (TextView)view.findViewById(R.id.acs);
                                String son = gsonStr.getText().toString();
                                intent.putExtra("activity",son);
                                startActivity(intent);
                                getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                            }
                        });
                    }
                };
                handler.post(runnable);
            }
        });

        //跳转到创建活动页面
        ImageView ivToCreateActivity = view.findViewById(R.id.iv_content_createactivity_zl);
        ivToCreateActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getContext(),CreateActivity.class);
                startActivity(intent);
            }
        });

        //初始化SlideMenu
        final SlideMenu slideMenu = (SlideMenu) view.findViewById(R.id.slideMenu);

        ImageView headImage = view.findViewById(R.id.top_head_image);
        headImage.setImageResource(R.drawable.project_detail_cir);

        headImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //创建左侧边框
                slideMenu.switchMenu();
            }
        });

        LinearLayout mainArea = view.findViewById(R.id.leftmenu_mainarea_zl);//头像域
        XCRoundImageView my_photo = view.findViewById(R.id.my_photo);
        XCRoundImageView top_my_photo = view.findViewById(R.id.top_head_image);
        LinearLayout getQian = view.findViewById(R.id.leftmenu_qian);//我的签到
        LinearLayout getFollowed = view.findViewById(R.id.leftmenu_follow);//关注的人
        TextView out = view.findViewById(R.id.out); // 注销按钮
        final LinearLayout getActivities = view.findViewById(R.id.leftmenu_activity);//创建的活动

        // 滑到左侧菜单栏，点击登陆
        final UserManager userManager = new UserManager();
        User user  =userManager.getCurrentUser();
        final TextView tvUsername =view.findViewById(R.id.leftmenu_username);
        //没有获取到用户名
        if (user==null){
            tvUsername.setText("登录");
            mainArea.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent);
                    getActivity().overridePendingTransition(R.anim.leftin,R.anim.rightout);
                }
            });
            //隐藏几个LinearLayout

            getQian.setVisibility(View.INVISIBLE);
            getFollowed.setVisibility(View.INVISIBLE);
            getActivities.setVisibility(View.INVISIBLE);
            out.setVisibility(View.INVISIBLE);

        }else{
            //添加用户名
            tvUsername.setText(user.getUserName());
            Glide.with(getActivity()).load(Const.BASE_URL+user.getUserImageUrl()).into(top_my_photo);
            Glide.with(getActivity()).load(Const.BASE_URL+user.getUserImageUrl()).into(my_photo);
            mainArea.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(getContext(),UserDetailActivity.class);
                    intent.putExtra("FINISH","finish");
                    startActivity(intent);
                    getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                }
            });

            //我的签到
            getQian.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(getContext(), SignActivity.class);
                    startActivity(intent);
                    getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                }
            });
            //我的关注的人
            getFollowed.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(getContext(),Star.class);
                    startActivity(intent);
                    getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                }
            });
            //我的活动
            getActivities.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(getContext(), MyCreateActivity.class);
                    startActivity(intent);
                    getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                }
            });


            // 注销按钮监听事件
            out.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    // 获取sharedPrece , 修改自动登录，记住密码， 将UserManganer 的user = null;
                    SharedPreferencesUtil  spu = new SharedPreferencesUtil(getActivity());
                    // 清空数据
                    spu.clear();
                    // 当前用户信息注销
                    UserManager userManager1 = new UserManager();
                    userManager1.clear();
                    Intent intent1 = new Intent(getActivity(),LoginActivity.class);
                    startActivity(intent1);
                }
            });
        }



        // 上拉动态图片刷新
        mPullToRefreshView = view.findViewById(R.id.pull_to_refresh);
        mPullToRefreshView.setOnRefreshListener(new PullToRefreshView.OnRefreshListener() {
            @Override
            public void onRefresh() {
                mPullToRefreshView.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mPullToRefreshView.setRefreshing(false);
                        Intent intent = new Intent(getActivity(),MainActivity.class);
                        startActivity(intent);
                    }
                }, 1000);
            }
        });

        return view;

    }


}

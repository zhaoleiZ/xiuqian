package com.example.windsoul.qianqian.bean;

public class Dresult {
    private int islike;
    private Discuss discuss;

    public int getIslike() {
        return islike;
    }

    public void setIslike(int islike) {
        this.islike = islike;
    }

    public Discuss getDiscuss() {
        return discuss;
    }

    public void setDiscuss(Discuss discuss) {
        this.discuss = discuss;
    }
}

package com.example.windsoul.qianqian.activity;

import android.content.Intent;

import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Result;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.google.gson.Gson;

import org.json.JSONObject;


import java.io.IOException;

import cn.smssdk.EventHandler;
import cn.smssdk.SMSSDK;
import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static android.content.ContentValues.TAG;


public class LoginByPhone extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "SmsYanzheng";

    private OkHttpClient okHttpClient;
    private int REQUEST_PERMISSION = 1;
    private int REQUEST_CODE = 2;
    EditText mEditTextPhoneNumber;
    EditText mEditTextCode;
    Button mButtonGetCode;
    TextView mButtonLogin;

    EventHandler eventHandler;
    String strPhoneNumber;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dxy_activity_login_byphone);

        mEditTextPhoneNumber = (EditText) findViewById(R.id.phone_number);
        mEditTextPhoneNumber.setFocusableInTouchMode(true);
        mEditTextPhoneNumber.setFocusable(true);
        mEditTextPhoneNumber.requestFocus();

        mEditTextCode = (EditText) findViewById(R.id.verification_code);
        mEditTextCode.setFocusableInTouchMode(true);
        mEditTextCode.setFocusable(true);

        mButtonGetCode = (Button) findViewById(R.id.button_send_verification_code);
        mButtonLogin = findViewById(R.id.button_login);

        mButtonGetCode.setOnClickListener(this);
        mButtonLogin.setOnClickListener(this);

        eventHandler = new EventHandler() {

            /**
             * 在操作之后被触发
             *
             * @param event  参数1
             * @param result 参数2 SMSSDK.RESULT_COMPLETE表示操作成功，为SMSSDK.RESULT_ERROR表示操作失败
             * @param data   事件操作的结果
             */

            @Override
            public void afterEvent(int event, int result, Object data) {
                Message message = myHandler.obtainMessage(0x00);
                message.arg1 = event;
                message.arg2 = result;
                message.obj = data;
                myHandler.sendMessage(message);
            }
        };

        TextView tvRegister = findViewById(R.id.register);
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginByPhone.this,RegisterActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.rightin,R.anim.leftout);
            }
        });

        ImageView ivBack = findViewById(R.id.iv_login_back_zl);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        SMSSDK.registerEventHandler(eventHandler);
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.leftin,R.anim.rightout);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        SMSSDK.unregisterEventHandler(eventHandler);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.button_login) {
            String strCode = mEditTextCode.getText().toString();
            if (null != strCode && strCode.length() == 4) {
                Log.d(TAG, mEditTextCode.getText().toString());
                SMSSDK.submitVerificationCode("86", strPhoneNumber, mEditTextCode.getText().toString());
            } else {
                Toast.makeText(this, "密码长度不正确", Toast.LENGTH_SHORT).show();
            }
        } else if (view.getId() == R.id.button_send_verification_code) {        //发送验证码button触发的事件
            strPhoneNumber = mEditTextPhoneNumber.getText().toString();
            if (null == strPhoneNumber || "".equals(strPhoneNumber) || strPhoneNumber.length() != 11) {
                Toast.makeText(this, "电话号码输入有误", Toast.LENGTH_SHORT).show();
                return;
            }

            //如果电话号码正确，那么调用发送验证码的接口
            SMSSDK.getVerificationCode("86", strPhoneNumber);
            mButtonGetCode.setClickable(false);
            //开启线程去更新button的text
            new Thread() {
                @Override
                public void run() {
                    int totalTime = 60;
                    for (int i = 0; i < totalTime; i++) {
                        Message message = myHandler.obtainMessage(0x01);
                        message.arg1 = totalTime - i;
                        myHandler.sendMessage(message);
                        try {
                            sleep(1000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                    myHandler.sendEmptyMessage(0x02);
                }
            }.start();
        }
    }

    Handler myHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0x00:
                    int event = msg.arg1;
                    int result = msg.arg2;
                    Object data = msg.obj;
                    Log.e(TAG, "result : " + result + ", event: " + event + ", data : " + data);
                    if (result == SMSSDK.RESULT_COMPLETE) { //回调  当返回的结果是complete
                        if (event == SMSSDK.EVENT_GET_VERIFICATION_CODE) { //获取验证码
                            Toast.makeText(LoginByPhone.this, "发送验证码成功", Toast.LENGTH_SHORT).show();
                            Log.d(TAG, "get verification code successful.");
                        } else if (event == SMSSDK.EVENT_SUBMIT_VERIFICATION_CODE) { //提交验证码
                            Log.d(TAG, "submit code successful");
                            Toast.makeText(LoginByPhone.this, "提交验证码成功", Toast.LENGTH_SHORT).show();

                            // 根据电话号码查找用户，将用户 放到 UserManager

                            // 写一个函数。。
                            findUserByPhone();


                            Intent intent = new Intent(LoginByPhone.this, MainActivity.class);
                            startActivity(intent);
                        } else {
                            Log.d(TAG, data.toString());
                        }
                    } else { //进行操作出错，通过下面的信息区分析错误原因
                        try {
                            Throwable throwable = (Throwable) data;
                            throwable.printStackTrace();
                            JSONObject object = new JSONObject(throwable.getMessage());
                            String des = object.optString("detail");//错误描述
                            int status = object.optInt("status");//错误代码
                            //错误代码：  http://wiki.mob.com/android-api-%E9%94%99%E8%AF%AF%E7%A0%81%E5%8F%82%E8%80%83/
                            Log.e(TAG, "status: " + status + ", detail: " + des);
                            if (status > 0 && !TextUtils.isEmpty(des)) {
                                Toast.makeText(LoginByPhone.this, des, Toast.LENGTH_SHORT).show();
                                return;
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    break;
                case 0x01:
                    mButtonGetCode.setText("重新发送(" + msg.arg1 + ")");
                    break;
                case 0x02:
                    mButtonGetCode.setText("获取验证码");
                    mButtonGetCode.setClickable(true);
                    break;
            }
        }
    };


    /**
     *
     */

    private void findUserByPhone() {

        Gson gson = new Gson();
        OkHttpClient okHttpClient = new OkHttpClient();

        final String phoneGson = gson.toJson(mEditTextPhoneNumber.getText().toString());

        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                phoneGson);
        //创建请求对象
        Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "/User/selectUserbyPhone.do")
                .build();

        //创建call对象，并执行请求
        final Call call = okHttpClient.newCall(request);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Response response = call.execute();
                    if (response.isSuccessful()) {//判断响应是否成功
                        String str = response.body().string();
                        Log.e(TAG, "同步：" + str);//获取服务器返回的字符串信息
                        Gson gson = new Gson();
                        User user = gson.fromJson(str, User.class);
                        if (user != null) {
                            UserManager userManager = new UserManager();
                            userManager.setCurrentUser(user);
                            Intent intent = new Intent(LoginByPhone.this, MainActivity.class);
                            startActivity(intent);
                            overridePendingTransition(R.anim.leftin, R.anim.rightout);
                        } else {

                        }

                    } else {
                        Log.e(TAG, response.code() + "连接失败");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("TGA", e.toString());
                }
            }
        }).start();

    }
}




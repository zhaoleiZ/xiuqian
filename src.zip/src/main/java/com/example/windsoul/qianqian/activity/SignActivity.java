package com.example.windsoul.qianqian.activity;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Action;
import com.example.windsoul.qianqian.bean.Discuss;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.example.windsoul.qianqian.util.XCRoundImageView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by 雪怡 on 2018/5/18.
 */

public class SignActivity extends Activity {
    private ListView contentListView;
    private ListAdapter adapter;
    private HashMap<String, View> map;
    private List<Map<String, Object>> data;
    private boolean is=false;
    private Handler handler;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dxy_activity_signin);
        //返回
        ImageView ivBack = findViewById(R.id.signin_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        handler = new Handler();

        Gson gson = new Gson();
        final User user = UserManager.getCurrentUser();

        RequestBody requestBody = RequestBody.create(MediaType.parse("application/json;charset=utf-8"),
                gson.toJson(user.getUserId()));
        final Request request = new Request.Builder().post(requestBody)
                .url(Const.BASE_URL+"Activity/selectAllActionbyuserId.do").build();
        OkHttpClient okHttpClient = new OkHttpClient();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String actionListStr = response.body().string();
                Log.e("SignActivity",actionListStr);
                Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1 = new TypeToken<List<Action>>() {}.getType();
                List<Action> actions = gson.fromJson(actionListStr, type1);
                data = new ArrayList<>();
                for(int i=0;i<actions.size();i++){
                    Map<String,Object> map = new HashMap<String,Object>();
                    map.put("image",actions.get(i).getActivityId().getActivityImageUrl());//头像
                    map.put("activityDetail",actions.get(i).getActivityId().getActivityTitle());//活动名
                    map.put("amount",actions.get(i).getSignInTime());//点赞天数

                    data.add(map);
                }
                contentListView = (ListView)findViewById(R.id.phb_lv);
                adapter = new ViewAdapter(SignActivity.this,R.layout.dxy_signinactivity1_item,data);
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView.setAdapter(adapter);
                    }
                };
                handler.post(runnable);
            }
        });


    }

    public class ViewAdapter extends BaseAdapter {

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;


        public ViewAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }


        @Override
        //返回当前Adapter数据项个数
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {


            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);

            }

            XCRoundImageView userimage = convertView.findViewById(R.id.iv_signin_zl);
            TextView content = convertView.findViewById(R.id.tv_signin_content_zl);
            TextView amount = convertView.findViewById(R.id.tv_signin_amount_zl);

            Map<String,Object> map = data.get(position);

            Glide.with(SignActivity.this).load(Const.BASE_URL+map.get("image")).into(userimage);
            content.setText(map.get("activityDetail").toString());
            amount.setText(map.get("amount")+"天");

            return convertView;

        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.leftin,R.anim.rightout);
    }
}

package com.example.windsoul.qianqian.fragment;

import android.content.Intent;
import android.os.Handler;
import android.support.v4.app.Fragment;
import android.content.Context;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.activity.ContentsDetail;
import com.example.windsoul.qianqian.activity.LoginActivity;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class Following extends Fragment {
    private ListView contentListView;
    private ListAdapter adapter;
    private HashMap<String, View> map;
    private List<Map<String, Object>> data;
    private boolean is=false;
    private Handler handler = null;

    @Override

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        final View views = inflater.inflate(R.layout.fragment_followed,
                container, false);
        handler = new Handler();

        /**
         * 直接去数据库请求数据了
         */

        UserManager userManager = new UserManager();
        User user = userManager.getCurrentUser();

        if (user == null) {

            Log.e("Tag", "走到这里啊");
            Runnable runnable = new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(getActivity(), LoginActivity.class);
                    startActivity(intent);
                }
            };
            handler.post(runnable);
        } else {

            Gson gson = new Gson();
            final String userGson = gson.toJson(user.getUserId());

            //创建请求体对象
            RequestBody requestBody = RequestBody.create(MediaType.parse("application/json;charset=utf-8"),
                    userGson);
            //创建请求对象
            Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                    .url(Const.BASE_URL + "Activity/selectAuserActivity.do")
                    .build();

            OkHttpClient okHttpClient = new OkHttpClient();
            Call call = okHttpClient.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String activityListStr = response.body().string();

                    Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                    Type type1 = new TypeToken<List<Activity>>() {
                    }.getType();
                    List<Activity> activities = gson.fromJson(activityListStr, type1);


                    data = new ArrayList<>();
                    // 从数据库中 拿到数据啊

                    ArrayList<Activity> acs = (ArrayList<Activity>) activities;

                    for (int i = 0; i < acs.size(); i++) {
                        Map<String, Object> map = new HashMap<String, Object>();
                        map.put("image", acs.get(i).getActivityImageUrl());
                        map.put("title", acs.get(i).getActivityTitle());
                        map.put("info", acs.get(i).getActivityIntroduce());
                        map.put("activity",gson.toJson(acs.get(i)));
                        data.add(map);
                    }

                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            contentListView = (ListView) views.findViewById(R.id.ls_followedactivity_zl);
                            adapter = new ViewAdapter(Following.this.getContext(), R.layout.content_list_item, data);
                            contentListView.setAdapter(adapter);

                            contentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                @Override
                                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                    Intent intent = new Intent(getActivity(),ContentsDetail.class);
                                    TextView gsonStr = (TextView)view.findViewById(R.id.acs);
                                    String son = gsonStr.getText().toString();
                                    intent.putExtra("activity",son);
                                    startActivity(intent);
                                    getActivity().overridePendingTransition(R.anim.rightin,R.anim.leftout);
                                }
                            });
                        }
                    };
                    handler.post(runnable);

                }
            });


        }
        return views;
    }

    public class ViewAdapter extends BaseAdapter{

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;

        public ViewAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);

            }

            ImageView images = (ImageView) convertView.findViewById(R.id.image);
            TextView title = (TextView) convertView.findViewById(R.id.title);
            TextView info = convertView.findViewById(R.id.info);
            Map<String,Object> map = data.get(position);
            Glide.with(context).load(Const.BASE_URL+map.get("image")).into(images);
            title.setText(map.get("title").toString());
            info.setText(map.get("info").toString());
            TextView acs = convertView.findViewById(R.id.acs);
            acs.setText(map.get("activity").toString());
            return convertView;
        }
    }
}

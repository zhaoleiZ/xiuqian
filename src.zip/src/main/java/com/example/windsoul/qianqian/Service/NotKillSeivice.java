package com.example.windsoul.qianqian.Service;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.util.Log;

import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.activity.MainActivity;
import com.example.windsoul.qianqian.util.AutoReceiver;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * Created by dell-pc on 2018/6/19.
 */

public class NotKillSeivice extends Service {

    private int runTime;
    private Binder binder = new Binder();
    //开关标记，判断程序是否被销毁，来记录时间

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.e("TAG","绑定服务");
        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.e("TAG","服务被创建");
        Notification notification = new Notification(R.drawable.bg, "通知",System.currentTimeMillis());
        Intent notificationIntent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, 0);


        // 通知
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm:ss");// HH:mm:ss
        //获取当前时间
        Date date = new Date(System.currentTimeMillis());
        Log.e("Date获取当前日期时间", simpleDateFormat.format(date));
        String time = simpleDateFormat.format(date);

        Calendar calendar = Calendar.getInstance();
        //获取时、分、秒
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int minute = calendar.get(Calendar.MINUTE);
        int second = calendar.get(Calendar.SECOND);
        Log.e("时分秒", hour + ":" + minute + ":" + second);


        //发送签到通知
        Intent intent = new Intent(this, AutoReceiver.class);
        intent.setAction("VIEDO_TIMER_NIGHT");
        // PendingIntent这个类用于处理即将发生的事情
        PendingIntent sender = PendingIntent.getBroadcast(this, 0, intent, 0);
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        int countNight = 21 * 60 * 60 - (hour * 60 * 60 + minute * 60 + second);
        Log.e("COUNT1", countNight + "");
        if (countNight > 0) {
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + countNight * 1000, am.INTERVAL_DAY, sender);
        } else {
            int count1 = 24 * 60 * 60 - countNight;
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + count1 * 1000, am.INTERVAL_DAY, sender);
        }
        //早上发送通知
        Intent intent1 = new Intent(this, AutoReceiver.class);
        intent1.setAction("VIEDO_TIMER_MORNING");
        PendingIntent pi = PendingIntent.getBroadcast(this, 0, intent1, 0);
        int countDay = 9 * 60 * 60 + 33*60 - (hour * 60 * 60 + minute * 60 + second);
        Log.e("COUNT2", countDay + "");
        if (countDay > 0) {
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + countDay * 1000, am.INTERVAL_DAY, pi);
        } else {
            int count2 = 24 * 60 * 60 - countDay;
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + count2 * 1000, am.INTERVAL_DAY, pi);
        }

        notification.contentIntent = PendingIntent.getActivity(this , 1 , intent , 0);

        //这里的id不能是0
        startForeground(1 , notification);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.e("TAG","解绑服务");
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onStart(Intent intent, int startId) {
        super.onStart(intent, startId);
    }
}

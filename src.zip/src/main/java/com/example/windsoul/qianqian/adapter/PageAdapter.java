package com.example.windsoul.qianqian.adapter;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.util.Const;

import java.util.List;
import java.util.Map;

/**
 * Created by felix on 15/4/30.
 */
public class PageAdapter extends BaseAdapter {

    private List<Map<String,Object>> data;
    private Context context;
    private int item_layout_id;

    public PageAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
        this.context = context;
        this.data = data;
        this.item_layout_id = item_layout_id;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            LayoutInflater m_inflater = LayoutInflater.from(context);
            convertView = m_inflater.inflate(item_layout_id,null);
        }

        ImageView images = (ImageView) convertView.findViewById(R.id.image);
        TextView title = (TextView) convertView.findViewById(R.id.title);
        TextView info = convertView.findViewById(R.id.info);
        TextView ggson = convertView.findViewById(R.id.acs);
        Map<String,Object> map = data.get(position);
        Glide.with(context).load(Const.BASE_URL+map.get("image")).into(images);
        title.setText(map.get("title").toString());
        info.setText(map.get("info").toString());

        ggson.setText(map.get("activity").toString());
        return convertView;
    }
}

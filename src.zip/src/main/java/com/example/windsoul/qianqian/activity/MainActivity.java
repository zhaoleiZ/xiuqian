package com.example.windsoul.qianqian.activity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.FrameLayout;
import android.widget.RadioButton;

import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.Service.NotKillSeivice;
import com.example.windsoul.qianqian.bean.Result;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.fragment.Content;
import com.example.windsoul.qianqian.fragment.Following;
import com.example.windsoul.qianqian.fragment.Phb;
import com.example.windsoul.qianqian.fragment.Search;
import com.example.windsoul.qianqian.util.AutoReceiver;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.SharedPreferencesUtil;
import com.example.windsoul.qianqian.util.UserManager;
import com.google.gson.Gson;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static android.content.ContentValues.TAG;


public class MainActivity extends AppCompatActivity {

        // 自动登陆

        private String userNumText;
        private String userPasswordText;
        private Handler handler = new Handler();
        //三个选项卡
        private RadioButton mRBtnFrist;
        private RadioButton mRBtnSecond;
        private RadioButton mRBtnThrid;
        private RadioButton mRBtnFourth;

        //存放fragment对应的容器
        private FrameLayout mFragmentContain;

        private Content content;
        private Phb phb;
        private Following following;
        private Search search;

        private FragmentManager manager;
        private Fragment currentFragment = new Fragment();

        private Binder binder;
        private ServiceConnection connection = new ServiceConnection() {
            @Override
            public void onServiceConnected(ComponentName name, IBinder service) {
                binder = (Binder) service;
                Log.e("MainTAG","服务绑定成功！");
            }

            @Override
            public void onServiceDisconnected(ComponentName name) {
                Log.e("MainTAG","服务断开成功！");
            }
        };

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            setContentView(R.layout.dxy_activity_main);

            Intent intent = new Intent(this,NotKillSeivice.class);
            startService(intent);

            mFragmentContain = (FrameLayout)findViewById(R.id.fl_contain);
            mRBtnFrist = (RadioButton)findViewById(R.id.rb_first);
            mRBtnSecond = (RadioButton)findViewById(R.id.rb_second);
            mRBtnThrid = (RadioButton)findViewById(R.id.rb_thrid);
            mRBtnFourth = (RadioButton)findViewById(R.id.rb_fourth);


    //      修改rediobutton图片的大小
            RadioButton[] rbs = new RadioButton[4];
         //初始化控件，中间大个的，周围小弟
            rbs[0] = mRBtnFrist;
            rbs[1] = mRBtnSecond;
            rbs[2] = mRBtnThrid;
            rbs[3] = mRBtnFourth;

            Drawable[] drs;
            for (RadioButton rb : rbs) {
                //挨着给每个RadioButton加入drawable限制边距以控制显示大小
                drs = rb.getCompoundDrawables();

                //获取drawables
                Rect r = new Rect(0, 0, drs[1].getMinimumWidth()/6, drs[1].getMinimumHeight()/6);
                //定义一个Rect边界
                drs[1].setBounds(r);
                //给drawable设置边界

                rb.setCompoundDrawables(null,drs[1],null,null);
                //添加限制给控件

                /**
                 *  初始化逻辑
                 */


                //注册事件监听器
                OnClickListenerImpl listener = new OnClickListenerImpl();
                mRBtnFrist.setOnClickListener(listener);
                mRBtnSecond.setOnClickListener(listener);
                mRBtnThrid.setOnClickListener(listener);
                mRBtnThrid.setOnClickListener(listener);
                mRBtnFourth.setOnClickListener(listener);
                //初始化页面对象
                content = new Content();
                search = new Search();
                phb = new Phb();
                following = new Following();
                //默认显示第1个页面
                changeFragment(content);
                mRBtnFrist.setChecked(true);
            }

            /**
             * 写自动登录的逻辑验证
             */
            UserManager userManager = new UserManager();
            User user = userManager.getCurrentUser();
            if(user==null) {
                AutoLogin();
            }

        }


    /**
     * 切换页面的方法
     * @param fragment 待切换的目标页面
     */
    private void changeFragment(Fragment fragment){
        //借助于FragmentManger和FragmentTransaction
        //首先判断FragmentManager是否为空
        if(null == manager){
            manager = getSupportFragmentManager();
        }
        //切换页面,每次切换页面，进行一次页面切换事务
        if(currentFragment != fragment){//如果当前显示的页面和目标要显示的页面不同
            //创建事务
            FragmentTransaction transaction = manager.beginTransaction();
            //删除当前页面
            transaction.remove(currentFragment);
            //判断待显示的页面是否已经添加过
//            if(!fragment.isAdded()){//待显示的页面没有被添加过
            transaction.add(R.id.fl_contain, fragment);
//            }
            //显示目标页面
            transaction.show(fragment);
            //提交事务
            transaction.commit();
            //更改当前页面
            currentFragment = fragment;
        }
    }
    private class OnClickListenerImpl implements View.OnClickListener{
        @RequiresApi(api = Build.VERSION_CODES.N)
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.rb_first://显示第1个页面
                    // 从数据库查找活动。
                    UserManager userManager = new UserManager();
                    User user = userManager.getCurrentUser();

                    changeFragment(content);
                    break;
                case R.id.rb_second://显示第2个页面
                   changeFragment(phb);
                    break;
                case R.id.rb_thrid://显示第3个页面
                    changeFragment(following);
                    break;
                case R.id.rb_fourth://显示第4个页面
                    changeFragment(search);
                    break;
            }
        }
    }

    // 自动登陆的逻辑判断
    private void  AutoLogin() {

        SharedPreferencesUtil spu = new SharedPreferencesUtil(this);
        Boolean isRemember = (Boolean) spu.getParam("isRememberPwd",false);
        Boolean isAutoLogin1 = (Boolean) spu.getParam("isAutoLogin",false);
        // SharedPreference获取用户账号密码，存在则填充
         userNumText = (String) spu.getParam("userNum","");
         userPasswordText = (String)spu.getParam("userPassword","");

        if(isAutoLogin1) {
            Login();
        }
    }


    // 登陆。。。
    private void Login() {


        final Gson gson = new Gson();
        User user = new User();
        user.setUserNum(userNumText);
        user.setUserPassword(userPasswordText);

        String userGson = gson.toJson(user);
        OkHttpClient okHttpClient = new OkHttpClient();
        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                userGson);
        //创建请求对象
        Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL+"/User/userlogin.do")
                .build();
        //创建call对象，并执行请求
        final Call call = okHttpClient.newCall(request);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Response response = call.execute();
                    if(response.isSuccessful()){
                        //判断响应是否成功，
                        String returnLogin = response.body().string();
                        Log.e(TAG,"同步："+returnLogin);//获取服务器返回的字符串信息
                        Result result = gson.fromJson(returnLogin,Result.class);
                        if(result.getCode()==0) {
                            Log.e("TGA","验证失败");
                            // 跳转到 活动页面
                            final Intent intent = new Intent(MainActivity.this,LoginActivity.class);
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    startActivity(intent);
                                }
                            },2000);
                        }else {// 判断 验证成功或者失败

                            // 获取当前用户登陆
                            // 并保存到 本地

                            UserManager userManager = new UserManager();
                            userManager.setCurrentUser(result.getUser());



                        }

                    }else{
                        Log.e(TAG,response.code()+"");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("TGA",e.toString());
                }
            }
        }).start();

    }


}
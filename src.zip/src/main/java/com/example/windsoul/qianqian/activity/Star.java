package com.example.windsoul.qianqian.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.fragment.Phb;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.example.windsoul.qianqian.util.XCRoundImageView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by dell-pc on 2018/5/23.
 */

public class Star extends AppCompatActivity {
    private ViewAdapter adapter;

    private List<Map<String, Object>> data;

    private ListView contentListView;
    private Handler handler;
    private List<User> users;

    int arr[];
    String arr2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.zl_activity_following);

        final User user = UserManager.getCurrentUser();
        int intId = user.getUserId();
        Gson gson = new Gson();
        String userId = gson.toJson(intId);

        handler = new Handler();

        //返回跳转过来的页面
        ImageView ivBack = findViewById(R.id.following_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //连接数据库
        OkHttpClient okHttpClient = new OkHttpClient();
        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                userId);
        //创建请求对象
        final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "/User/userAllAttention.do")
                .build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String userListStr = response.body().string();

                Log.e("String",userListStr);

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<User>>(){}.getType();
                users=gson.fromJson(userListStr,type1);


                data = new ArrayList<>();
                // 从数据库中 拿到数据啊

                ArrayList<User> acs = (ArrayList<User>) users;

                for (int i=0;i<acs.size();i++) {
                    Map<String,Object> map = new HashMap<String, Object>();
                    map.put("userImg",acs.get(i).getUserImageUrl());
                    map.put("userId",acs.get(i).getUserId());
                    map.put("username",acs.get(i).getUserName());
                    map.put("userMsg",acs.get(i).getUserIntroduce());
                    map.put("userContent","这里是用户的最新动态");
                    //TODO 从数据库中获取用户的最新动态

                    data.add(map);
                }

                contentListView = (ListView)findViewById(R.id.ls_following);

                adapter = new ViewAdapter(Star.this,R.layout.zl_layout_following_item,data);

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView.setAdapter(adapter);
                    }
                };
                handler.post(runnable);

                //item点击事件
                contentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        TextView tvUserId = view.findViewById(R.id.following_userid_zl);
                        final int userId = Integer.parseInt((String) tvUserId.getText());
                        Runnable runnable = new Runnable() {
                            @Override
                            public void run() {
                                //从数据库获取用户信息
                                //连接数据库
                                OkHttpClient userOkHttp = new OkHttpClient();
                                //创建请求体对象
                                RequestBody userRequestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                                        String.valueOf(userId));
                                //创建请求对象
                                final Request userRequest = new Request.Builder().post(userRequestBody)//设置成post请求,参数是请求体
                                        .url(Const.BASE_URL + "User/selectAUserbyuserId.do")
                                        .build();
                                Call call = userOkHttp.newCall(userRequest);
                                call.enqueue(new Callback() {
                                    @Override
                                    public void onFailure(Call call, IOException e) {
                                        e.printStackTrace();
                                    }

                                    @Override
                                    public void onResponse(Call call, Response response) throws IOException {
                                        String userGson = response.body().string();
                                        Log.e("userGson",userGson);
                                        Intent intent = new Intent(Star.this,FollowingUserDetailActivity.class);
                                        intent.putExtra("userGson",userGson);
                                        startActivity(intent);
                                    }
                                });
                            }
                        };
                        handler.post(runnable);
                    }
                });
            }
        });

    }

    public class ViewAdapter extends BaseAdapter {

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;


        public ViewAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }


        @Override
        //返回当前Adapter数据项个数
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {

            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {


            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);

            }


            XCRoundImageView userImg = (XCRoundImageView) convertView.findViewById(R.id.following_user_img);
            TextView userid = (TextView) convertView.findViewById(R.id.following_userid_zl);
            TextView username = (TextView) convertView.findViewById(R.id.following_username);
            TextView userMsg = (TextView) convertView.findViewById(R.id.following_user_msg);
            TextView userContent = (TextView) convertView.findViewById(R.id.following_user_content);

            Map<String,Object> map = data.get(position);

//            userImg.setImageResource((int)map.get("userImg"));

            Glide.with(context).load(Const.BASE_URL+map.get("userImg")).into(userImg);
            userid.setText(map.get("userId").toString());
            username.setText(map.get("username").toString());
            userMsg.setText(map.get("userMsg").toString());
            //TODO 把用户的最新动态放入TextView中
            userContent.setText(map.get("userContent").toString());

            Button btnFollowed = convertView.findViewById(R.id.following_btn_followed);
            btnFollowed.setOnClickListener(new FollowedBtnListener(data.get(position),position));

            return convertView;

        }
    }

    private class FollowedBtnListener implements View.OnClickListener{
        private Map<String,Object> map;
        private int position;
        public FollowedBtnListener(Map<String,Object> map,int position){
            this.map = map;
            this.position = position;
        }

        @Override
        public void onClick(View v) {
            arr = new int[2];
            arr[0] = UserManager.getCurrentUser().getUserId();
            arr[1] = users.get(position).getUserId();
            Gson  gson1 = new Gson();
            arr2 =  gson1.toJson(arr);

            final Button btnFollowed = v.findViewById(R.id.following_btn_followed);

            //连接数据库
            OkHttpClient okHttpClient = new OkHttpClient();
            //创建请求体对象
            RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                    arr2);
            //创建请求对象
            final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                    .url(Const.BASE_URL + "/User/userAttendioninsert.do")
                    .build();
            Call call = okHttpClient.newCall(request);
            call.enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    e.printStackTrace();
                }
                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    String info = response.body().string();

                    Log.e("String",info);
                    Gson gson3 = new Gson();

                    int flag = gson3.fromJson(info,int.class);
                    Log.e("TGA","------> flag" + flag);
                    if (flag==1) {// 关注成功
                        Log.e("tag","---------->关注成功");

                        Runnable runnable = new Runnable() {
                            @Override
                            public void run() {
                                btnFollowed.setText("已关注");
                            }
                        };
                        handler.post(runnable);


                    }
                    else if(flag==2) { //取消关注成功

                        Runnable runnable = new Runnable() {
                            @Override
                            public void run() {
                                btnFollowed.setText("添加关注");
                            }
                        };
                        handler.post(runnable);


                    } else { // 操作失败
                        Log.e("tag","操作失败");
                    }
                }
            });
        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.leftin,R.anim.rightout);
    }

    //TODO 动画跳转
//    @Override
//    public void startActivity(Intent intent) {
//        super.startActivity(intent);
//        overridePendingTransition(R.anim.rightin,R.anim.leftout);
//    }
}

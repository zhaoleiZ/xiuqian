package com.example.windsoul.qianqian.function;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;

import com.example.windsoul.qianqian.R;


/**
 * Created by dell-pc on 2018/5/9.
 */

public class FindPsdByPhone extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.find_by_phonenum);

    }
}

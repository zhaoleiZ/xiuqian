package com.example.windsoul.qianqian.util;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.util.Log;

import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.activity.MainActivity;

import static android.content.Context.NOTIFICATION_SERVICE;

/**
 * Created by dell-pc on 2018/6/15.
 */

public class AutoReceiver extends BroadcastReceiver {
    private static final int NOTIFICATION_FLAG = 1;
    @SuppressLint("NewApi")
    @Override
    public void onReceive(Context context, Intent intent) {
//        Log.e("晚上",intent.getAction().equals("VIEDO_TIMER_NIGHT")+"");
//        Log.e("白天",intent.getAction().equals("VIEDO_TIMER_MORNING")+"");

        if (intent.getAction().equals("VIEDO_TIMER_NIGHT")) {
            Log.e("TAG","晚上通知执行");

            Intent intent_noti = new Intent(context,MainActivity.class);
            PendingIntent pendingIntent =
                    PendingIntent.getActivity(context,
                            0,intent_noti,
                            PendingIntent.FLAG_CANCEL_CURRENT);
            //获取通知管理器
            NotificationManager manager = (NotificationManager)
                    context.getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                //创建通知管道，第三个参数是级别
                NotificationChannel channel =
                        new NotificationChannel("管道id","管道名",NotificationManager.IMPORTANCE_HIGH);
                //添加通知管道
                manager.createNotificationChannel(channel);
            }
            Notification.Builder builder = new Notification.Builder(context)
                    .setContentTitle("XIU签")
                    .setContentText("该签到了！")
                    .setSmallIcon(R.drawable.bg)
                    .setLargeIcon(BitmapFactory.decodeResource(context.getResources(),R.drawable.bg))
                    .setContentIntent(pendingIntent)//绑定pendingIntent
                    .setAutoCancel(true);//自动消失
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                //有版本控制，所以必须单独使用，不能链式调用
                builder.setChannelId("管道id");
            }
            Notification noti = builder.build();
            manager.notify(0,noti);
        } else if(intent.getAction().equals("VIEDO_TIMER_MORNING")){
            Log.e("TAG","早上通知执行");

            Intent intent_noti = new Intent(context,MainActivity.class);
            PendingIntent pendingIntent =
                    PendingIntent.getActivity(context,
                            0,intent_noti,
                            PendingIntent.FLAG_CANCEL_CURRENT);
            //获取通知管理器
            NotificationManager manager = (NotificationManager)
                    context.getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                //创建通知管道，第三个参数是级别
                NotificationChannel channel =
                        new NotificationChannel("管道id","管道名",NotificationManager.IMPORTANCE_HIGH);
                //添加通知管道
                manager.createNotificationChannel(channel);
            }
            Notification.Builder builder = new Notification.Builder(context)
                    .setContentTitle("XIU签")
                    .setContentText("今天也要加油鸭！")
                    .setSmallIcon(R.drawable.bg)
                    .setLargeIcon(BitmapFactory.decodeResource(context.getResources(),R.drawable.bg))
                    .setContentIntent(pendingIntent)//绑定pendingIntent
                    .setAutoCancel(true);//自动消失
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                //有版本控制，所以必须单独使用，不能链式调用
                builder.setChannelId("管道id");
            }
            Notification noti = builder.build();
            manager.notify(0,noti);
        }
    }
}

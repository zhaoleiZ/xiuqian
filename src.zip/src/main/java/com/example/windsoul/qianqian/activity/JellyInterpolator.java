package com.example.windsoul.qianqian.activity;

/**
 * Created by 雪怡 on 2018/5/9.
 */
import android.view.animation.LinearInterpolator;

public class JellyInterpolator extends LinearInterpolator {
    private float factor;

    public JellyInterpolator() {
        this.factor = 0.15f;
    }

    @Override
    public float getInterpolation(float input) {
        return (float) (Math.pow(2, -10 * input)
                * Math.sin((input - factor / 4) * (2 * Math.PI) / factor) + 1);
    }
}


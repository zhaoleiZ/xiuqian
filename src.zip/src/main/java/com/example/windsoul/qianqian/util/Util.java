package com.example.windsoul.qianqian.util;

import android.content.Context;
import android.graphics.Color;
import android.os.Environment;
import android.widget.Toast;

import com.example.windsoul.qianqian.bean.Action;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.bean.User;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

/**
 * @author: Lemon-XQ
 * @date: 2017/11/12
 * @description: 功能类，封装一些本地的数据， 主要是 排行榜。
 */

public class Util {



   private static ArrayList<Activity> activities = new ArrayList<Activity>();

    private static ArrayList<User> users = new ArrayList<User>();

    private static  ArrayList<Action> actions = new ArrayList<Action>();

    public static ArrayList<Action> getActions() {
        return actions;
    }

    public static void setActions(ArrayList<Action> actions) {
        Util.actions = actions;
    }

    public static ArrayList<Activity> getActivities() {
        return activities;
    }

    public static void setActivities(ArrayList<Activity> activities) {
        Util.activities = activities;
    }

    public static ArrayList<User> getUsers() {
        return users;
    }

    public static void setUsers(ArrayList<User> users) {
        Util.users = users;
    }
}

package com.example.windsoul.qianqian.bean;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.Objects;


public class AdminS {
    private int adminId;
    private String adminName;
    private String adminPassword;


    public int getAdminId() {
        return adminId;
    }

    public void setAdminId(int adminId) {
        this.adminId = adminId;
    }


    public String getAdminName() {
        return adminName;
    }

    public void setAdminName(String adminName) {
        this.adminName = adminName;
    }


    public String getAdminPassword() {
        return adminPassword;
    }

    public void setAdminPassword(String adminPassword) {
        this.adminPassword = adminPassword;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AdminS adminS = (AdminS) o;
        return adminId == adminS.adminId &&
                Objects.equals(adminName, adminS.adminName) &&
                Objects.equals(adminPassword, adminS.adminPassword);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {

        return Objects.hash(adminId, adminName, adminPassword);
    }
}

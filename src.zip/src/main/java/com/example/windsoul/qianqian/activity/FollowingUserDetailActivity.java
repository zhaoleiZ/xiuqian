package com.example.windsoul.qianqian.activity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Activity;
import com.example.windsoul.qianqian.bean.Discuss;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.fragment.Following;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.example.windsoul.qianqian.util.XCRoundImageView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by dell-pc on 2018/6/5.
 */

public class FollowingUserDetailActivity extends AppCompatActivity {

    private ListView contentListView;
    private ListAdapter adapter;
    private List<Map<String, Object>> data;
    private Handler handler;
    private Button Guanzhu;
    private User user;
    // 当前用户关注此用户
    int arr[];
    String arr2;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.zl_following_user_detail);

        Intent intent = getIntent();
        Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();


        handler = new Handler();
        // intent 跳啊
        String userGson = intent.getStringExtra("userGson");
        user = gson.fromJson(userGson,User.class);

        UserManager userManager = new UserManager();

        arr = new int[2];
        arr[0] = userManager.getCurrentUser().getUserId();
        arr[1] = user.getUserId();
        Gson  gson1 = new Gson();
        arr2 =  gson1.toJson(arr);

        //关注的人
        final TextView followingCount = findViewById(R.id.following_followed_zl);
        //连接数据库
        OkHttpClient okHttpClient = new OkHttpClient();
        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                gson.toJson(user.getUserId()));
        //创建请求对象
        final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "User/userAllAttention.do")
                .build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String userListStr = response.body().string();

                Log.e("String",userListStr);

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<User>>(){}.getType();
                final List<User> users=gson.fromJson(userListStr,type1);

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        followingCount.setText(users.size()+"");
                    }
                };
                handler.post(runnable);
            }
        });

        //关注的活动数
        final TextView activitiesCount = findViewById(R.id.following_activity_zl);

        Request request1 = new Request.Builder().post(requestBody)
                .url(Const.BASE_URL+"Activity/selectAuserActivity.do").build();
        Call call1 = okHttpClient.newCall(request1);
        call1.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String activitiesStr = response.body().string();
                Log.e("activitiesStr",activitiesStr);

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<com.example.windsoul.qianqian.bean.Activity>>(){}.getType();
                final List<com.example.windsoul.qianqian.bean.Activity> activities=gson.fromJson(activitiesStr,type1);

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        activitiesCount.setText(activities.size()+"");
                    }
                };
                handler.post(runnable);
            }
        });

        //签到数
        final TextView signinCount = findViewById(R.id.following_signin_zl);

        Request request2 = new Request.Builder().post(requestBody)
                .url(Const.BASE_URL+"Activity/selectAllDiscussbyuserId.do").build();
        Call call2 = okHttpClient.newCall(request2);
        call2.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String discussStr = response.body().string();
                Log.e("discussStr",discussStr);

                Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1 = new TypeToken<List<Discuss>>() {}.getType();
                final List<Discuss> discusses = gson.fromJson(discussStr, type1);

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        signinCount.setText(discusses.size()+"");
                    }
                };
                handler.post(runnable);
            }
        });

        //关注按钮
        Guanzhu = findViewById(R.id.btn_is_followed_zl);

        // 先判断当前用户是否关注了此用户
        GuanzhuPeople();


        // 关注按钮逻辑
        Guanzhu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Guanzhu();
            }
        });



        ImageView ivBack = findViewById(R.id.iv_following_back_zl);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        //用户头像
        XCRoundImageView ivImage = findViewById(R.id.iv_following_img_zl);
        Glide.with(this).load(Const.BASE_URL+user.getUserImageUrl()).into(ivImage);
        //用户名
        TextView tvName = findViewById(R.id.tv_following_name_zl);
        tvName.setText(user.getUserName());
        //用户的简介
        TextView tvIntroduce = findViewById(R.id.tv_following_introduce_zl);
        tvIntroduce.setText(user.getUserIntroduce());

        String userId = gson.toJson(user.getUserId());
        Log.e("userid",userId);
        //创建请求体对象
        RequestBody requestBody3 = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                userId);
        //创建请求对象
        final Request request3 = new Request.Builder().post(requestBody3)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "/Activity/selectAllDiscussbyuserId.do")
                .build();
        Call call3 = okHttpClient.newCall(request3);
        call3.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String discussStrList = response.body().string();
                Log.e("str",discussStrList);

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<Discuss>>(){}.getType();
                List<Discuss> discusses=gson.fromJson(discussStrList,type1);

                data = new ArrayList<>();
                for(int i=0;i<discusses.size();i++){
                    Map<String,Object> map = new HashMap<String,Object>();
                    map.put("username",user.getUserName());
                    map.put("userImg",user.getUserImageUrl());

                    map.put("praise",String.valueOf(discusses.get(i).getDiscussPraise()));
                    map.put("introduce",discusses.get(i).getDiscussIntroduce());
                    map.put("activity",discusses.get(i).getActionId().getActivityId().getActivityIntroduce());
                    Date date = discusses.get(i).getDiscussTime();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String dateStr = sdf.format(date);
                    map.put("time",dateStr);

                    data.add(map);
                }

                contentListView = (ListView) findViewById(R.id.lv_following_zl);
                adapter = new ViewAdapter(FollowingUserDetailActivity.this,R.layout.dxy_userdetail_list_item,data);

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView.setAdapter(adapter);
                    }
                };
                handler.post(runnable);
            }
        });


        adapter = new ViewAdapter(FollowingUserDetailActivity.this, R.layout.dxy_userdetail_list_item,data);

    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.leftin,R.anim.rightout);
    }
    private class ViewAdapter extends BaseAdapter{
        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;

        public ViewAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }

        @Override
        //返回当前Adapter数据项个数
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);
            }

            TextView tvUsername = convertView.findViewById(R.id.tv_userdetail_username_zl);
            XCRoundImageView userImg = convertView.findViewById(R.id.userdetail_userimg_zl);
            TextView tvTime = convertView.findViewById(R.id.tv_userdetail_last_zl);
            TextView tvPraise = convertView.findViewById(R.id.tv_userdetail_zancount_zl);
            TextView tvTitle = convertView.findViewById(R.id.userdetail_title_zl);
            TextView tvContent = convertView.findViewById(R.id.userdetail_content_zl);

            Map<String,Object> map = data.get(position);
            Log.e("abc",map.get("username").toString());
            tvUsername.setText(map.get("username").toString());
            Glide.with(FollowingUserDetailActivity.this).load(Const.BASE_URL+map.get("userImg")).into(userImg);
            tvPraise.setText(map.get("praise").toString());
            tvTime.setText(map.get("time").toString());
            tvTitle.setText(map.get("activity").toString());
            tvContent.setText(map.get("introduce").toString());
            return convertView;
        }
    }


    /**
     * 此用户关注的人
     */
    private void GuanzhuPeople() {

        User currentUser = UserManager.getCurrentUser();
        Gson gson = new Gson();
        //连接数据库
        OkHttpClient okHttpClient = new OkHttpClient();
        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                gson.toJson(currentUser.getUserId()));
        //创建请求对象
        final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "/User/userAllAttention.do")
                .build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String userListStr = response.body().string();
                Log.e("FollowingUserDetail",userListStr);

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<User>>(){}.getType();
                List<User> users=gson.fromJson(userListStr,type1);

                Intent intent = getIntent();
                String gsonStr = intent.getStringExtra("userGson");
                User gsonUser = gson.fromJson(gsonStr,User.class);

                for (int i=0;i<users.size();i++) {
                    if(gsonUser.getUserNum().equals(users.get(i).getUserNum())) { // 说明此用户关注的人里面有当前用户
                        Guanzhu.setText("已关注");
                    }else {
                        Guanzhu.setText("添加关注");
                    }

            }
        }
    });

    }

    /**
     *  关注逻辑
     */

    private void Guanzhu() { // 当前用户关注了此用户

        //连接数据库
        OkHttpClient okHttpClient = new OkHttpClient();
        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                arr2);
        //创建请求对象
        final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "/User/userAttendioninsert.do")
                .build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String info = response.body().string();

                Log.e("String",info);
                Gson gson3 = new Gson();

                int flag = gson3.fromJson(info,int.class);
                Log.e("TGA","------> flag" + flag);
                if (flag==1) {// 关注成功
                    Log.e("tag","---------->关注成功");

                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            Guanzhu.setText("已关注");
                        }
                    };
                    handler.post(runnable);


                }
                else if(flag==2) { //取消关注成功

                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            Guanzhu.setText("添加关注");
                        }
                    };
                    handler.post(runnable);


                } else { // 操作失败
                    Log.e("tag","操作失败");
                }
            }
        });


    }

}


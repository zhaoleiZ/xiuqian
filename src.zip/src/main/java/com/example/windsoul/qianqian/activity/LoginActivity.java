package com.example.windsoul.qianqian.activity;

import android.animation.Animator;
import android.animation.Animator.AnimatorListener;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.Window;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Result;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.SharedPreferencesUtil;
import com.example.windsoul.qianqian.util.UserManager;
import com.google.gson.Gson;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static android.content.ContentValues.TAG;

public class LoginActivity extends Activity  {

    Handler handler = new Handler();
    private String returnLogin;

    private OkHttpClient okHttpClient;
    private int REQUEST_PERMISSION = 1;
    private int REQUEST_CODE = 2;

    private TextView mBtnLogin;
    private TextView userNum;
    private TextView userPassword;
    private TextView textView;
    private CheckBox isRememberPwd;
    private CheckBox isAutoLogin;
    private View progress;
    private View mInputLayout;
    private float mWidth, mHeight;
    private TextView byPhone;

    // 注册逻辑的组件
    private  TextView register;

    private LinearLayout mName, mPsw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);

        setContentView(R.layout.my_login);

        // 登陆初始化逻辑
        initComponents();
        // 监听
        setListeners();

        // 自动填充
        SharedPreferencesUtil spu = new SharedPreferencesUtil(this);
        Boolean isRemember = (Boolean) spu.getParam("isRememberPwd",false);
        Boolean isAutoLogin1 = (Boolean) spu.getParam("isAutoLogin",false);
        // SharedPreference获取用户账号密码，存在则填充
        String userNumText = (String) spu.getParam("userNum","");
        String userPasswordText = (String)spu.getParam("userPassword","");
//        if(!userNumText.equals("") && !userPasswordText.equals("")){
//            if(isRemember){
//
//                userNum.setText(userNumText);
//                userPassword.setText(userPasswordText);
//                isRememberPwd.setChecked(true);
//            }
//            if(isAutoLogin1) {
//                isAutoLogin.setChecked(true);
//                httpLogin();
//            }
//
//        }
    }

    // 初始化组件
    void initComponents(){

        // 手机验证
        byPhone = findViewById(R.id.by_phone);


        /**
         * 找到 学号 密码
         */
        userNum = findViewById(R.id.userNum);
        userPassword = findViewById(R.id.userPassword);

        register = findViewById(R.id.btn_register);
        //给忘记密码添加下划线main_btn_forgetpassword
//        textView  = findViewById(R.id.main_btn_forgetpassword);
//        textView.getPaint().setFlags(Paint.UNDERLINE_TEXT_FLAG);
        mBtnLogin = (TextView) findViewById(R.id.button_login);
        progress = findViewById(R.id.layout_progress);
        mInputLayout = findViewById(R.id.input_layout);
        mName = findViewById(R.id.input_layout_name);
        mPsw = findViewById(R.id.input_layout_psw);

        isRememberPwd = findViewById(R.id.login_remember);
        isAutoLogin = findViewById(R.id.login_auto);

        UserManager.clear();
    }


    void setListeners(){

        // 手机验证
        byPhone.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,LoginByPhone.class);
                startActivity(intent);
                overridePendingTransition(R.anim.leftin,R.anim.rightout);
            }
        });

        mBtnLogin.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                mWidth = mBtnLogin.getMeasuredWidth();
                mHeight = mBtnLogin.getMeasuredHeight();

                mName.setVisibility(View.INVISIBLE);
                mPsw.setVisibility(View.INVISIBLE);

                inputAnimator(mInputLayout, mWidth, mHeight);

                httpLogin();
            }
        });

        //创建OKHttpClient
        okHttpClient = new OkHttpClient();//默认方法

//        //忘记密码跳转到忘记密码页
//        textView.setOnClickListener(new OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent = new Intent(LoginActivity.this,ResetPasswordActivity.class);
//                startActivity(intent);
//                overridePendingTransition(R.anim.leftin,R.anim.rightout);
//            }
//        });

        // 注册(动画效果)

        register.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
                overridePendingTransition(R.anim.leftin,R.anim.rightout);
            }
        });


    }


    private void inputAnimator(final View view, float w, float h) {

        AnimatorSet set = new AnimatorSet();

        ValueAnimator animator = ValueAnimator.ofFloat(0, w);
        animator.addUpdateListener(new AnimatorUpdateListener() {

            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                float value = (Float) animation.getAnimatedValue();
                MarginLayoutParams params = (MarginLayoutParams) view
                        .getLayoutParams();
                params.leftMargin = (int) value;
                params.rightMargin = (int) value;
                view.setLayoutParams(params);
            }
        });

        ObjectAnimator animator2 = ObjectAnimator.ofFloat(mInputLayout,
                "scaleX", 1f, 0.5f);
        set.setDuration(1000);
        set.setInterpolator(new AccelerateDecelerateInterpolator());
        set.playTogether(animator, animator2);
        set.start();
        set.addListener(new AnimatorListener() {

            @Override
            public void onAnimationStart(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {
                // TODO Auto-generated method stub

            }

            @Override
            public void onAnimationEnd(Animator animation) {

                progress.setVisibility(View.VISIBLE);
                progressAnimator(progress);
                mInputLayout.setVisibility(View.INVISIBLE);

            }

            @Override
            public void onAnimationCancel(Animator animation) {
                // TODO Auto-generated method stub

            }
        });

    }

    private void progressAnimator(final View view) {
        PropertyValuesHolder animator = PropertyValuesHolder.ofFloat("scaleX",
                0.5f, 1f);
        PropertyValuesHolder animator2 = PropertyValuesHolder.ofFloat("scaleY",
                0.5f, 1f);
        ObjectAnimator animator3 = ObjectAnimator.ofPropertyValuesHolder(view,
                animator, animator2);
        animator3.setDuration(1000);
        animator3.setInterpolator(new JellyInterpolator());
        animator3.start();


    }



    /**
     * 连接服务器
     */

    private void httpLogin() {

        // 检查数据格式是否正确
        String resMsg = checkDataValid(userNum.getText().toString(), userPassword.getText().toString());
        if (!resMsg.equals("")) {
            showResponse(resMsg);
            return;
        }

        // 处理自动登录及记住密码
        OptionHandle(userNum.getText().toString(), userPassword.getText().toString());

        final Gson gson = new Gson();
        User user = new User();
        user.setUserNum(userNum.getText().toString());
        user.setUserPassword(userPassword.getText().toString());

        String userGson = gson.toJson(user);

        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                userGson);
        //创建请求对象
        Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL+"/User/userlogin.do")
                .build();
        //创建call对象，并执行请求
        final Call call = okHttpClient.newCall(request);
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Response response = call.execute();
                    if(response.isSuccessful()){
                        //判断响应是否成功，
                        returnLogin = response.body().string();
                        Log.e(TAG,"同步："+returnLogin);//获取服务器返回的字符串信息
                        Result result = gson.fromJson(returnLogin,Result.class);

                        if(result.getCode()==0) {
                           Log.e("TGA","验证失败");
                            // 跳转到 活动页面
                            final Intent intent = new Intent(LoginActivity.this,LoginActivity.class);


                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    startActivity(intent);
                                }
                            },2000);
                        }else {// 判断 验证成功或者失败

                            // 跳转到 活动页面
                            final Intent intent = new Intent(LoginActivity.this,MainActivity.class);

                            // 获取当前用户登陆
                            // 并保存到 本地

                            UserManager userManager = new UserManager();
                            userManager.setCurrentUser(result.getUser());

                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    startActivity(intent);
                                }
                            },2000);

                        }

                    }else{
                        Log.e(TAG,response.code()+"");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("TGA",e.toString());
                }
            }
        }).start();

    }



    private String checkDataValid(String account,String pwd){
        if(TextUtils.isEmpty(account) | TextUtils.isEmpty(pwd))
            return "用户名密码不能为空";
//        if(account.length() != 11 && !account.contains("@"))
//            return "格式不正确";
        return "";
    }

    void OptionHandle(String account,String pwd){
        SharedPreferences.Editor editor = getSharedPreferences("UserData",MODE_PRIVATE).edit();
        SharedPreferencesUtil spu = new SharedPreferencesUtil(this);
        if(isRememberPwd.isChecked()){
            editor.putBoolean("isRememberPwd",true);
            // 保存账号密码
            spu.setParam("userNum",account);
            spu.setParam("userPassword",pwd);
        }else{
            editor.putBoolean("isRememberPwd",false);
        }
        if(isAutoLogin.isChecked()){
            editor.putBoolean("isAutoLogin",true);
        }else{
            editor.putBoolean("isAutoLogin",false);
        }
        editor.apply();
    }


    private void showResponse(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(LoginActivity.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

}

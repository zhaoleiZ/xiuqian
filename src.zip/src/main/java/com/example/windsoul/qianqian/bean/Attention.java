package com.example.windsoul.qianqian.bean;

import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.Objects;

public class Attention {
    private Integer attentionId;
    private User userId;
    private User attentionuserId;



    public User getUserId() {
        return userId;
    }

    public void setUserId(User userId) {
        this.userId = userId;
    }


    public User getAttentionuserId() {
        return attentionuserId;
    }

    public void setAttentionuserId(User attentionuserId) {
        this.attentionuserId = attentionuserId;
    }


    public Integer getAttentionId() {
        return attentionId;
    }

    public void setAttentionId(Integer attentionId) {
        this.attentionId = attentionId;
    }


    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Attention attention = (Attention) o;
        return Objects.equals(attentionId, attention.attentionId);
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {

        return Objects.hash(attentionId);
    }
}

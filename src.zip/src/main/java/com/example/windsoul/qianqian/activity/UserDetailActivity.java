package com.example.windsoul.qianqian.activity;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Discuss;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.example.windsoul.qianqian.util.XCRoundImageView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by 雪怡 on 2018/5/15.
 */

public class UserDetailActivity extends Activity {

    private ListView contentListView;
    private ListAdapter adapter;
    private List<Map<String, Object>> data;
    private Handler handler;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dxy_activity_user_detail);


        handler = new Handler();

        final Gson gson = new Gson();
        final User user = UserManager.getCurrentUser();

        //关注的人数
        final TextView followingCount = findViewById(R.id.tv_userdetail_followingcount_zl);

        //连接数据库
        OkHttpClient okHttpClient = new OkHttpClient();
        //创建请求体对象
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                gson.toJson(user.getUserId()));
        //创建请求对象
        final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "User/userAllAttention.do")
                .build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String userListStr = response.body().string();

                Log.e("String",userListStr);

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<User>>(){}.getType();
                final List<User> users=gson.fromJson(userListStr,type1);

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        followingCount.setText(users.size()+"");
                    }
                };
                handler.post(runnable);
            }
        });

        //关注的活动数
        final TextView activitiesCount = findViewById(R.id.tv_userdetail_activitycount_zl);

        Request request1 = new Request.Builder().post(requestBody)
                .url(Const.BASE_URL+"Activity/selectAuserActivity.do").build();
        Call call1 = okHttpClient.newCall(request1);
        call1.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String activitiesStr = response.body().string();
                Log.e("activitiesStr",activitiesStr);

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<com.example.windsoul.qianqian.bean.Activity>>(){}.getType();
                final List<com.example.windsoul.qianqian.bean.Activity> activities=gson.fromJson(activitiesStr,type1);

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        activitiesCount.setText(activities.size()+"");
                    }
                };
                handler.post(runnable);
            }
        });

        //签到数
        final TextView signinCount = findViewById(R.id.tv_userdetail_signincount_zl);

        Request request2 = new Request.Builder().post(requestBody)
                .url(Const.BASE_URL+"Activity/selectAllDiscussbyuserId.do").build();
        Call call2 = okHttpClient.newCall(request2);
        call2.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String discussStr = response.body().string();
                Log.e("discussStr",discussStr);

                Gson gson = new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1 = new TypeToken<List<Discuss>>() {}.getType();
                final List<Discuss> discusses = gson.fromJson(discussStr, type1);

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        signinCount.setText(discusses.size()+"");
                    }
                };
                handler.post(runnable);
            }
        });


        //返回到跳转过来的页面
        ImageView lvBack = findViewById(R.id.iv_userdetail_back_zl);
        lvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                String finishStr = intent.getStringExtra("FINISH");
                if(finishStr.equals("change")){
                    Intent intent1 = new Intent(UserDetailActivity.this,MainActivity.class);
                    startActivity(intent1);
                }else{
                    finish();
                }
            }
        });

        TextView tv1 = findViewById(R.id.grzx);
        tv1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(UserDetailActivity.this,ResetUserDetailActivity.class);
                startActivity(intent);
            }
        });

        //获取用户名，用户头像
        String name = user.getUserName();
        TextView username = findViewById(R.id.user_username_zl);
        username.setText(user.getUserName());
        XCRoundImageView userImage = findViewById(R.id.user_userimage_zl);
        Glide.with(this).load(Const.BASE_URL+user.getUserImageUrl()).into(userImage);
        TextView userIntroduce = findViewById(R.id.user_introduce_zl);
        userIntroduce.setText(user.getUserIntroduce());

        String userId = gson.toJson(user.getUserId());
        //连接数据库
        OkHttpClient okHttpClient3 = new OkHttpClient();
        //创建请求体对象
        RequestBody requestBody3 = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                userId);
        //创建请求对象
        final Request request3 = new Request.Builder().post(requestBody3)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "/Activity/selectAllDiscussbyuserId.do")
                .build();
        Call call3 = okHttpClient3.newCall(request3);
        call3.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String discussStrList = response.body().string();

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<Discuss>>(){}.getType();
                List<Discuss> discusses=gson.fromJson(discussStrList,type1);

                data = new ArrayList<>();
                for(int i=0;i<discusses.size();i++){
                    Map<String,Object> map = new HashMap<String,Object>();
                    map.put("username",user.getUserName());
                    map.put("userImg",user.getUserImageUrl());

                    map.put("praise",String.valueOf(discusses.get(i).getDiscussPraise()));
                    map.put("introduce",discusses.get(i).getDiscussIntroduce());
                    map.put("activity",discusses.get(i).getActionId().getActivityId().getActivityIntroduce());
                    Date date = discusses.get(i).getDiscussTime();
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    String dateStr = sdf.format(date);
                    map.put("time",dateStr);

                    data.add(map);
                }

                contentListView = (ListView)findViewById(R.id.lv_my_userdetail_zl);
                adapter = new ViewAdapter(UserDetailActivity.this,R.layout.dxy_userdetail_list_item,data);

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView.setAdapter(adapter);
                    }
                };
                handler.post(runnable);
            }
        });

    }

    public class ViewAdapter extends BaseAdapter {

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;


        public ViewAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }


        @Override
        //返回当前Adapter数据项个数
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {


            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);
            }

            TextView tvUsername = convertView.findViewById(R.id.tv_userdetail_username_zl);
            XCRoundImageView userImg = convertView.findViewById(R.id.userdetail_userimg_zl);
            TextView tvTime = convertView.findViewById(R.id.tv_userdetail_last_zl);
            TextView tvPraise = convertView.findViewById(R.id.tv_userdetail_zancount_zl);
            TextView tvTitle = convertView.findViewById(R.id.userdetail_title_zl);
            TextView tvContent = convertView.findViewById(R.id.userdetail_content_zl);

            Map<String,Object> map = data.get(position);
            Log.e("abc",map.get("username").toString());
            tvUsername.setText(map.get("username").toString());
            Glide.with(UserDetailActivity.this).load(Const.BASE_URL+map.get("userImg")).into(userImg);
            tvPraise.setText(map.get("praise").toString());
            tvTime.setText(map.get("time").toString());
            tvTitle.setText(map.get("activity").toString());
            tvContent.setText(map.get("introduce").toString());
            return convertView;

        }
    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.leftin,R.anim.rightout);
    }
}

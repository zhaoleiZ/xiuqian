package com.example.windsoul.qianqian.activity;

import android.Manifest;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
//import android.support.design.widget.FloatingActionButton;
//import android.support.design.widget.Snackbar;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.example.windsoul.qianqian.util.XCRoundImageView;
import com.google.gson.Gson;

import java.io.File;
import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class ResetUserDetailActivity extends AppCompatActivity {


    private int REQUEST_PERMISSION = 1;
    private int REQUEST_CODE = 2;
    private OkHttpClient okHttpClient;
    private Handler handler;
    private User user;
    private XCRoundImageView userImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dxy_activity_reset_user_detail);
        ImageView back = findViewById(R.id.backtouserdetail);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        TextView btnChange = findViewById(R.id.userdetail_change_btn_zl);

        okHttpClient = new OkHttpClient();
        handler = new Handler();

        user = UserManager.getCurrentUser();

        //用户头像
        userImage = findViewById(R.id.reset_top_head_image_zl);
        Glide.with(this).load(Const.BASE_URL+user.getUserImageUrl()).into(userImage);
        //点击更换头像
        userImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //打开手机相册，动态申请权限
                requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                        REQUEST_PERMISSION);
            }
        });

        //个性签名
        final EditText userIntroduce = findViewById(R.id.reset_input_layout_introduce_zl);
        userIntroduce.setHint(user.getUserIntroduce());
        userIntroduce.setFocusableInTouchMode(true);
        userIntroduce.setFocusable(true);
        userIntroduce.requestFocus();
        //清空信息
        ImageView introduceDelete = findViewById(R.id.register_delete_introduce_zl);
        introduceDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userIntroduce.setText("");
            }
        });

        //密码和确认密码
        final EditText password = findViewById(R.id.register_et_password_zl);
        password.setFocusableInTouchMode(true);
        password.setFocusable(true);
        ImageView passwordDelete = findViewById(R.id.register_delete_psd_zl);
        passwordDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                password.setText("");
            }
        });
        final EditText repassword = findViewById(R.id.register_et_repassword_zl);
        repassword.setFocusableInTouchMode(true);
        repassword.setFocusable(true);
        ImageView repasswordDelete = findViewById(R.id.register_delete_repsd_zl);
        repasswordDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                repassword.setText("");
            }
        });

        //电话
        final EditText phone = findViewById(R.id.register_et_phone_zl);
        phone.setHint(user.getUserPhone());
        phone.setFocusableInTouchMode(true);
        phone.setFocusable(true);
        ImageView phnoeDelete = findViewById(R.id.register_delete_phone_zl);
        phnoeDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                phone.setText("");
            }
        });

        btnChange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!userIntroduce.getText().toString().isEmpty()){
                    user.setUserIntroduce(userIntroduce.getText().toString());
                }
                if(password.getText().toString().equals(repassword.getText().toString())
                        && !password.getText().toString().isEmpty()
                        && !repassword.getText().toString().isEmpty()){
                    user.setUserPassword(password.getText().toString());
                }else if(password.getText().toString().isEmpty() && repassword.getText().toString().isEmpty()){
                    String passwordStr = user.getUserPassword();
                    user.setUserPassword(passwordStr);
                }else{
                    Runnable runnable = new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(ResetUserDetailActivity.this,"密码不一致",Toast.LENGTH_LONG).show();
                        }
                    };
                    handler.post(runnable);
                }
                if (!phone.getText().toString().isEmpty()){
                    user.setUserPhone(phone.getText().toString());
                }
                Gson gson = new Gson();
                String userStr = gson.toJson(user);
                Log.e("userStr",userStr);

                RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                        userStr);
                Request request = new Request.Builder().post(requestBody)
                        .url(Const.BASE_URL+"User/updateusermsg.do")
                        .build();
                Call call = okHttpClient.newCall(request);
                call.enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        Boolean isSuccess = Boolean.valueOf(response.body().string());
                        if(isSuccess){
                            Runnable runnable = new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(ResetUserDetailActivity.this,"修改成功",Toast.LENGTH_LONG).show();
                                }
                            };
                            handler.post(runnable);
                        }else{
                            Runnable runnable = new Runnable() {
                                @Override
                                public void run() {
                                    Toast.makeText(ResetUserDetailActivity.this,"修改失败",Toast.LENGTH_LONG).show();
                                }
                            };
                            handler.post(runnable);
                        }
                    }
                });
                Intent intent = new Intent(ResetUserDetailActivity.this,UserDetailActivity.class);
                intent.putExtra("FINISH","change");
                startActivity(intent);
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == REQUEST_CODE){
            //获取照片
            Uri uri = data.getData();//获取图片的Uri
            //后四个参数是查询的字段，条件等
            Cursor cursor = this.getContentResolver().query(uri,null,null,null,null);
            cursor.moveToFirst();
            //MediaStore媒体库 MediaStore.Images.Media.DATA;本质就是一个字符串
            String column = MediaStore.Images.Media.DATA;
            int columnIndex = cursor.getColumnIndex(column);
            String path = cursor.getString(columnIndex);//获取路径（在SD卡中的地址）
            File file = new File(path);
            doUploadFile(file);
        }
    }

    //申请动态权限的回调方法
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        //打开手机相册
        Intent intent = new Intent();
        intent.setAction(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent,REQUEST_CODE);
    }

    private void doUploadFile(File file){
        //构造请求体
        RequestBody requestBody = RequestBody.create(MediaType.parse("image/*"),file);
        //创建请求
        final Request request = new Request.Builder().url(Const.BASE_URL+"/UploadFile").post(requestBody).build();
        //执行
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                final String path = response.body().string();
                user.getUserImageUrl();//活动的图片
                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        Log.e("路径：",Const.BASE_URL+path);
                        user.setUserImageUrl(path);
                        Glide.with(ResetUserDetailActivity.this).load(Const.BASE_URL+path).into(userImage);
                    }
                };
                handler.post(runnable);
            }
        });
    }
}

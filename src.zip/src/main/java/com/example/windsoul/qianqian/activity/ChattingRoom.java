package com.example.windsoul.qianqian.activity;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.v7.app.AppCompatActivity;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.windsoul.qianqian.R;
import com.example.windsoul.qianqian.bean.Action;
import com.example.windsoul.qianqian.bean.Discuss;
import com.example.windsoul.qianqian.bean.Dresult;
import com.example.windsoul.qianqian.bean.User;
import com.example.windsoul.qianqian.fragment.Phb;
import com.example.windsoul.qianqian.util.CommentEditext;
import com.example.windsoul.qianqian.util.Const;
import com.example.windsoul.qianqian.util.UserManager;
import com.example.windsoul.qianqian.util.XCRoundImageView;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Created by windsoul on 2018/6/12.
 */

public class ChattingRoom extends AppCompatActivity {

    // 评论点赞插入
    int[] setlike = new int[2];



    // 将留言插入到数据库
    private String arr3[] = new String[3];

    // 需要传的活动ID的gson
    private String activityId;
    // 点击item时 需要进入用户详情页面
    private String userId;
    private Handler handler;
    private ListView contentListView;
    private ViewAdapter adapter;
    private HashMap<String, View> map;
    private List<Map<String, Object>> data;
    private int[] islike;
    List<Dresult> dresults = new ArrayList<>();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dxy_activity_messageboard);
        // 判断当前用户是否点赞过
        islike = new int[2];



        ImageView back = findViewById(R.id.backtodetail);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        handler = new Handler();
        final CommentEditext question_input = findViewById(R.id.question_input);

        int id = getIntent().getIntExtra("activityId",1);
        String activityTitle = getIntent().getStringExtra("activity_title");
        Gson gson = new Gson();
        activityId = gson.toJson(id);

        UserManager userManager = new UserManager();
        User user = userManager.getCurrentUser();
        arr3[0] = user.getUserName();
        arr3[1] = activityTitle;

        islike[0] = user.getUserId();
        islike[1] = id;

        setlike[0] = user.getUserId();



        /**
         * 进入留言板时，肯定像访问服务器，查询评论，并把数据放到 data
         */
        getDiscuss();



        /**
         * 当选择发表评论时，将当前数据插入到数据库，并且再次查询评论，放到data,再次刷新。
         */

        TextView submit_question = findViewById(R.id.submit_question);
        submit_question.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 先插入
                String str = question_input.getText().toString();
                arr3[2] = str;


                setDiscuss();

                question_input.setText("");


            }
        });

        // 最后在查询一遍
        // 再查询

    }


    public class ViewAdapter extends BaseAdapter {

        private List<Map<String,Object>> data;
        private Context context;
        private int item_layout_id;

        public ViewAdapter(Context context, int item_layout_id, List<Map<String,Object>> data) {
            this.context = context;
            this.data = data;
            this.item_layout_id = item_layout_id;
        }

        @Override
        public int getCount() {
            return data.size();
        }

        @Override
        public Object getItem(int position) {
            return data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                LayoutInflater m_inflater = LayoutInflater.from(context);
                convertView = m_inflater.inflate(item_layout_id,null);

            }

            XCRoundImageView images =  convertView.findViewById(R.id.head_imge);
            TextView user_name = (TextView) convertView.findViewById(R.id.user_name);
            TextView text_years = convertView.findViewById(R.id.text_yeas);
            TextView text_content = convertView.findViewById(R.id.text_content);
            TextView user_id = convertView.findViewById(R.id.user_id);



            Map<String,Object> map = data.get(position);

            // 拿一下 discuss gson
            TextView discuss233 = convertView.findViewById(R.id.discuss233);
            discuss233.setText(map.get("discuss233").toString());


            Glide.with(context).load(Const.BASE_URL+map.get("image")).into(images);
            user_name.setText(map.get("user_name").toString());
            text_years.setText(map.get("text_years").toString());
            text_content.setText(map.get("text_content").toString());
            user_id.setText(map.get("user").toString());
            ImageView like = convertView.findViewById(R.id.like_zl);
            // 判断 是否点赞

            if(map.get("islike").toString().equals("1")) {
                like.setImageResource(R.drawable.is_successed);
//                Log.e("tag"," islike ----->");
            }


            like.setOnClickListener(new ImageClickListener(data.get(position),position));

            return convertView;
        }
    }

    //添加监听器类
    public class ImageClickListener implements View.OnClickListener{
        private Map<String,Object> map;
        private int position;
        public ImageClickListener(Map<String,Object> map,int position){
            this.map = map;
            this.position = position;
        }

        @Override
        public void onClick(View v) {
            ImageView like = v.findViewById(R.id.like_zl);

            Discuss discuss233 =
                    dresults.get(position).getDiscuss();

            if (like.getDrawable().getCurrent().getConstantState().equals(getResources().getDrawable(R.drawable.like).getConstantState())){
                like.setImageResource(R.drawable.is_successed);
                // 插入数据库

                setlike[1] = discuss233.getDiscussId();
//                Log.e("tag","点赞信息插入到数据库的 disID ------->" + discuss233.getDiscussId());
                setLike();

            } else {
                like.setImageResource(R.drawable.like);
                setlike[1] = discuss233.getDiscussId();
//                Log.e("tag","删除点赞信息到数据库的 disID ------->" + discuss233.getDiscussId());
                setLike();

            }

        }
    }

    /**
     * 向数据库查询留言内容,并放到listview
     */
    private void getDiscuss() {

        Gson gson = new Gson();
        OkHttpClient okHttpClient = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                gson.toJson(islike));
        final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "Activity/selectAllDisscussByactivityId.do")
                .build();
        Call call1 = okHttpClient.newCall(request);
        call1.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String info = response.body().string();

                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                Type type1=new TypeToken<List<Dresult>>(){}.getType();

                // 如果某活动没有评论，会返回空的Json
                dresults = gson.fromJson(info,type1);
                Log.e("tag",info);

                data = new ArrayList<>();
                // 从数据库中 拿到数据啊
                // 把晴空，在重新查询一遍。
                data.clear();
                Log.e("tag","----> data 晴空后的size " + data.size());
                for (int i=0;i<dresults.size();i++) {
                    Map<String,Object> map = new HashMap<String, Object>();
                    map.put("islike",dresults.get(i).getIslike());
//                    Log.e("tag","当前用户是否已点赞------->"+dresults.get(i).getIslike());
                    Discuss discuss = dresults.get(i).getDiscuss();
                    map.put("image",discuss.getActionId().getUserId().getUserImageUrl());
                    map.put("user_name",discuss.getActionId().getUserId().getUserName());
                    map.put("text_years",discuss.getDiscussTime());
                    map.put("text_content",discuss.getDiscussIntroduce());
                    map.put("user",gson.toJson(discuss.getActionId().getUserId()));

                    Gson gson233 = new Gson();
                    String discuss233 =  gson233.toJson(discuss);
                    map.put("discuss233",discuss233);

                    data.add(map);

                }
                Log.e("tag","----> data 加载后的size " + data.size());

                Runnable runnable = new Runnable() {
                    @Override
                    public void run() {
                        contentListView = findViewById(R.id.dxy_messageboard);
                        adapter = new ViewAdapter(ChattingRoom.this,R.layout.dxy_layout_message_item,data);
                        // 刷新adapter
//                        adapter.notifyDataSetChanged();

                        contentListView.setAdapter(adapter);
                        contentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                                TextView tt = view.findViewById(R.id.user_id);
                                String userGson = tt.getText().toString();
                                // 判断一下，当前点击的用户是自己还是别人
                                // 自己的话就跳自己的用户详情
                                // 别人的跳别人的用户详情

                                UserManager userManager = new UserManager();
                                User currentUser = userManager.getCurrentUser();
                                Gson gs = new Gson();
                                User user = gs.fromJson(userGson,User.class);

                                if (currentUser.getUserName().equals(user.getUserName())) { //跳自己
                                    Intent intent = new Intent(ChattingRoom.this,UserDetailActivity.class);
                                    startActivity(intent);
                                    overridePendingTransition(R.anim.rightin,R.anim.leftout);
                                }else {// 跳别人
                                    Intent intent = new Intent(ChattingRoom.this,FollowingUserDetailActivity.class);
                                    intent.putExtra("userGson",userGson);
                                    startActivity(intent);
                                    overridePendingTransition(R.anim.rightin,R.anim.leftout);
                                }

                            }
                        });

                    }
                };
                handler.post(runnable);

            }

        });

    }


    /**
     *插入留言到数据库中
     */
    private void setDiscuss() {
        Gson gson = new Gson();

        OkHttpClient okHttpClient = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                gson.toJson(arr3));
        final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "Activity/userpublishDiscuss.do")
                .build();
        Call call1 = okHttpClient.newCall(request);
        call1.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String info = response.body().string();
                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                boolean flag = gson.fromJson(info,boolean.class);
                if(flag) {
                    Log.e("TGA","发表成功");
                    getDiscuss();
                }

            }

        });

    }

    @Override
    public void finish() {
        super.finish();
        overridePendingTransition(R.anim.leftin,R.anim.rightout);
    }

    /**
     *   点赞插入数据库
     */
    private void setLike() {

        Gson gson = new Gson();

        OkHttpClient okHttpClient = new OkHttpClient();
        RequestBody requestBody = RequestBody.create(MediaType.parse("text/plain;charset=utf-8"),
                gson.toJson(setlike));
        final Request request = new Request.Builder().post(requestBody)//设置成post请求,参数是请求体
                .url(Const.BASE_URL + "Activity/discusspraiseUpdate.do")
                .build();
        Call call1 = okHttpClient.newCall(request);
        call1.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String info = response.body().string();
                Gson gson=new GsonBuilder().setDateFormat("yyyy-MM-dd").disableHtmlEscaping().create();
                int flag = gson.fromJson(info,int.class);
                if(flag==1) {
//                    Log.e("TGA","----> 点赞插入成功");
                } else {
//                    Log.e("TGA","----> 取消点赞成功");
                }

            }

        });


    }

}
